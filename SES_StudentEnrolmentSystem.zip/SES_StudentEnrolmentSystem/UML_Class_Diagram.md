# UML Class Diagram - Student Enrollment System

## Overview
This UML class diagram represents the Student Enrollment System architecture, showing the relationships between Model, DAO, Service, Database, and UI layers.

---

## UML Class Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                              MODEL LAYER (ses.model)                             │
└─────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────┐
│         Student              │
├──────────────────────────────┤
│ - id: String {final}         │
│ - firstName: String          │
│ - surname: String            │
│ - email: String              │
│ - dateOfBirth: String        │
│ - programme: String          │
├──────────────────────────────┤
│ + Student(id, firstName,     │
│   surname, email, dob,       │
│   programme)                 │
│ + getId(): String            │
│ + getFirstName(): String     │
│ + setFirstName(String)       │
│ + getSurname(): String       │
│ + setSurname(String)         │
│ + getFullName(): String      │
│ + getEmail(): String         │
│ + setEmail(String)           │
│ + getDateOfBirth(): String   │
│ + setDateOfBirth(String)     │
│ + getProgramme(): String     │
│ + setProgramme(String)       │
│ + toString(): String         │
└──────────────────────────────┘


┌──────────────────────────────┐          ┌──────────────────────────────┐
│          Course              │          │           Grade              │
├──────────────────────────────┤          ├──────────────────────────────┤
│ - code: String {final}       │          │ - score: double {final}      │
│ - title: String {final}      │          ├──────────────────────────────┤
│ - credits: int {final}       │          │ + Grade(score)               │
├──────────────────────────────┤          │ + getScore(): double         │
│ + Course(code, title,        │          │ + isPass(): boolean          │
│   credits)                   │          │ + toString(): String         │
│ + getCode(): String          │          └──────────────────────────────┘
│ + getTitle(): String         │                       △
│ + getCredits(): int          │                       │
│ + toString(): String         │                       │ 0..1
│ + equals(Object): boolean    │                       │
│ + hashCode(): int            │          ┌────────────┴─────────────────┐
└──────────────────────────────┘          │                              │
                △                         │                              │
                │                         │                              │
                │ 1                       │                              │
                │                         │                              │
┌───────────────┴──────────────────────────────────────────┐             │
│                    Enrollment                            │             │
├──────────────────────────────────────────────────────────┤             │
│ - student: Student {final}                               │◄────────────┘
│ - course: Course {final}                                 │
│ - semester: String {final}                               │
│ - grade: Grade                                           │
├──────────────────────────────────────────────────────────┤
│ + Enrollment(student, course, semester)                  │
│ + getStudent(): Student                                  │
│ + getCourse(): Course                                    │
│ + getSemester(): String                                  │
│ + getGrade(): Grade                                      │
│ + setGrade(Grade)                                        │
│ + isCompleted(): boolean                                 │
│ + toString(): String                                     │
└──────────────────────────────────────────────────────────┘
                △
                │ 1
                │
                │


┌─────────────────────────────────────────────────────────────────────────────────┐
│                          DATABASE LAYER (ses.database)                           │
└─────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────┐    ┌──────────────────────────────────┐
│      DatabaseConnection                  │    │    DatabaseInitializer           │
├──────────────────────────────────────────┤    ├──────────────────────────────────┤
│ - URL: String {static final}             │    │                                  │
│ - USERNAME: String {static final}        │    ├──────────────────────────────────┤
│ - PASSWORD: String {static final}        │    │ + initializeTables(): void       │
├──────────────────────────────────────────┤    │   {static}                       │
│ + getConnection(): Connection {static}   │    └──────────────────────────────────┘
│ + closeConnection(Connection) {static}   │
└──────────────────────────────────────────┘
                △
                │ uses
                │


┌─────────────────────────────────────────────────────────────────────────────────┐
│                            DAO LAYER (ses.dao)                                   │
└─────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│           StudentDAO                     │
├──────────────────────────────────────────┤
│                                          │
├──────────────────────────────────────────┤
│ + addStudent(Student): void              │
│ + getStudentById(String): Student        │
│ + getAllStudents(): List<Student>        │
│ + updateStudent(Student): void           │
│ + deleteStudent(String): void            │
│ + studentExists(String): boolean         │
│ + getNextStudentId(): String             │
└──────────────────────────────────────────┘
                │ uses
                ▼
        DatabaseConnection


┌──────────────────────────────────────────┐
│           CourseDAO                      │
├──────────────────────────────────────────┤
│                                          │
├──────────────────────────────────────────┤
│ + addCourse(Course): void                │
│ + getCourseByCode(String): Course        │
│ + getAllCourses(): List<Course>          │
│ + courseExists(String): boolean          │
│ + deleteCourse(String): void             │
│ + updateCourse(Course): void             │
└──────────────────────────────────────────┘
                │ uses
                ▼
        DatabaseConnection


┌──────────────────────────────────────────┐
│         EnrollmentDAO                    │
├──────────────────────────────────────────┤
│ - studentDAO: StudentDAO                 │
│ - courseDAO: CourseDAO                   │
├──────────────────────────────────────────┤
│ + addEnrollment(Enrollment): void        │
│ + getEnrollmentsByStudent(String):       │
│   List<Enrollment>                       │
│ + getAllEnrollments(): List<Enrollment>  │
│ + updateGrade(String, String, String,    │
│   double): void                          │
│ + enrollmentExists(String, String,       │
│   String): boolean                       │
└──────────────────────────────────────────┘
                │ uses
                ▼
        DatabaseConnection
                │ uses
                ▼
        StudentDAO, CourseDAO


┌─────────────────────────────────────────────────────────────────────────────────┐
│                          SERVICE LAYER (ses.service)                             │
└─────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                    EnrollmentService                             │
├──────────────────────────────────────────────────────────────────┤
│ - studentDAO: StudentDAO                                         │
│ - courseDAO: CourseDAO                                           │
│ - enrollmentDAO: EnrollmentDAO                                   │
├──────────────────────────────────────────────────────────────────┤
│ + registerStudent(id, firstName, surname, email, dob,           │
│   programme): Student                                            │
│ + addCourse(code, title, credits): void                          │
│ + getAllCourses(): List<Course>                                  │
│ + enrolStudent(studentId, courseCode, semester): Enrollment      │
│ + recordGrade(studentId, courseCode, semester, score): void      │
│ + getStudentById(studentId): Student                             │
│ + getNextStudentId(): String                                     │
│ + getStudentReport(studentId): List<Enrollment>                  │
│ + getAllStudents(): List<Student>                                │
│ + getAllEnrollments(): List<Enrollment>                          │
│ + updateStudent(id, firstName, surname, email, dob,              │
│   programme): void                                               │
└──────────────────────────────────────────────────────────────────┘
                │ uses
                ▼
    StudentDAO, CourseDAO, EnrollmentDAO


┌─────────────────────────────────────────────────────────────────────────────────┐
│                              UI LAYER (ses.ui)                                   │
└─────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│            MainFrame                     │
│          extends JFrame                  │
├──────────────────────────────────────────┤
│ - service: EnrollmentService             │
│ - cardLayout: CardLayout                 │
│ - mainPanel: JPanel                      │
├──────────────────────────────────────────┤
│ + MainFrame(EnrollmentService)           │
│ - createMenuBar(): JMenuBar              │
│ - createNavigationPanel(): JPanel        │
│ - createWelcomePanel(): JPanel           │
│ - showPanel(String): void                │
└──────────────────────────────────────────┘
                │ contains
                ▼
    ┌───────────────────────────────────┐
    │  StudentPanel, EnrollmentPanel,   │
    │  GradePanel, CoursesCompletedPanel│
    │  ReportPanel                      │
    └───────────────────────────────────┘


┌──────────────────────────────────────────┐
│          StudentPanel                    │
│          extends JPanel                  │
├──────────────────────────────────────────┤
│ - service: EnrollmentService             │
│ - studentTable: JTable                   │
│ - tableModel: DefaultTableModel          │
├──────────────────────────────────────────┤
│ + StudentPanel(EnrollmentService)        │
│ - createRegisterPanel(): JPanel          │
│ - createProfilePanel(): JPanel           │
│ - loadStudents(): void                   │
│ - registerStudent(): void                │
│ - updateStudent(): void                  │
└──────────────────────────────────────────┘


┌──────────────────────────────────────────┐
│        EnrollmentPanel                   │
│          extends JPanel                  │
├──────────────────────────────────────────┤
│ - service: EnrollmentService             │
│ - enrollmentTable: JTable                │
│ - tableModel: DefaultTableModel          │
├──────────────────────────────────────────┤
│ + EnrollmentPanel(EnrollmentService)     │
│ - createEnrollmentForm(): JPanel         │
│ - loadEnrollments(): void                │
│ - enrollStudent(): void                  │
└──────────────────────────────────────────┘


┌──────────────────────────────────────────┐
│           GradePanel                     │
│          extends JPanel                  │
├──────────────────────────────────────────┤
│ - service: EnrollmentService             │
├──────────────────────────────────────────┤
│ + GradePanel(EnrollmentService)          │
│ - createGradeForm(): JPanel              │
│ - recordGrade(): void                    │
└──────────────────────────────────────────┘


┌──────────────────────────────────────────┐
│      CoursesCompletedPanel               │
│          extends JPanel                  │
├──────────────────────────────────────────┤
│ - service: EnrollmentService             │
│ - completedTable: JTable                 │
│ - tableModel: DefaultTableModel          │
├──────────────────────────────────────────┤
│ + CoursesCompletedPanel(                 │
│   EnrollmentService)                     │
│ - createSearchPanel(): JPanel            │
│ - searchCompletedCourses(): void         │
└──────────────────────────────────────────┘


┌──────────────────────────────────────────┐
│          ReportPanel                     │
│          extends JPanel                  │
├──────────────────────────────────────────┤
│ - service: EnrollmentService             │
│ - reportTable: JTable                    │
│ - tableModel: DefaultTableModel          │
├──────────────────────────────────────────┤
│ + ReportPanel(EnrollmentService)         │
│ - createSearchPanel(): JPanel            │
│ - generateReport(): void                 │
└──────────────────────────────────────────┘


┌──────────────────────────────────────────┐
│        BackgroundPanel                   │
│          extends JPanel                  │
├──────────────────────────────────────────┤
│ - image: BufferedImage                   │
│ - scaledCache: BufferedImage             │
│ - mode: Mode                             │
│ - showBackground: boolean                │
├──────────────────────────────────────────┤
│ + BackgroundPanel(resourcePath, mode)    │
│ + setShowBackground(boolean): void       │
│ + isExternalImageLoaded(): boolean       │
│ # paintComponent(Graphics): void         │
└──────────────────────────────────────────┘


┌──────────────────────────────────────────┐
│              UIFont                      │
├──────────────────────────────────────────┤
│ + TITLE: Font {static final}             │
│ + LABEL: Font {static final}             │
│ + BUTTON: Font {static final}            │
└──────────────────────────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────────┐
│                            MAIN APPLICATION                                      │
└─────────────────────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│              Main                        │
├──────────────────────────────────────────┤
│                                          │
├──────────────────────────────────────────┤
│ + main(String[]): void {static}          │
└──────────────────────────────────────────┘
                │ creates
                ▼
        EnrollmentService
                │ creates
                ▼
            MainFrame


═══════════════════════════════════════════════════════════════════════════════════
                              RELATIONSHIP SUMMARY
═══════════════════════════════════════════════════════════════════════════════════

INHERITANCE:
  • All UI panels extend JPanel
  • MainFrame extends JFrame

COMPOSITION:
  • Enrollment contains Student (1:1)
  • Enrollment contains Course (1:1)
  • Enrollment contains Grade (0..1 - optional)

AGGREGATION:
  • EnrollmentService has StudentDAO, CourseDAO, EnrollmentDAO
  • EnrollmentDAO has StudentDAO, CourseDAO
  • All UI panels have EnrollmentService
  • MainFrame has EnrollmentService

DEPENDENCY:
  • All DAOs use DatabaseConnection
  • DatabaseInitializer uses DatabaseConnection
  • Main creates EnrollmentService and MainFrame

═══════════════════════════════════════════════════════════════════════════════════
                              DESIGN PATTERNS
═══════════════════════════════════════════════════════════════════════════════════

1. DAO Pattern (Data Access Object)
   - StudentDAO, CourseDAO, EnrollmentDAO separate data access from business logic

2. Service Layer Pattern
   - EnrollmentService provides business logic and coordinates DAOs

3. MVC Pattern (Model-View-Controller)
   - Model: Person, Student, Course, Enrollment, Grade
   - View: MainFrame, StudentPanel, EnrollmentPanel, etc.
   - Controller: EnrollmentService (coordinates between View and Model)

4. Singleton-like Pattern
   - DatabaseConnection provides static methods for connection management

5. Template Method Pattern
   - BackgroundPanel provides customizable background rendering

═══════════════════════════════════════════════════════════════════════════════════
```

## Key Relationships

### Model Layer
- **Enrollment** → **Student** (composition, 1:1)
- **Enrollment** → **Course** (composition, 1:1)
- **Enrollment** → **Grade** (composition, 0..1)

### Data Access Layer
- **StudentDAO** → DatabaseConnection (dependency)
- **CourseDAO** → DatabaseConnection (dependency)
- **EnrollmentDAO** → DatabaseConnection, StudentDAO, CourseDAO (dependency)

### Service Layer
- **EnrollmentService** → StudentDAO, CourseDAO, EnrollmentDAO (aggregation)

### UI Layer
- **MainFrame** → EnrollmentService (aggregation)
- **All Panels** → EnrollmentService (aggregation)
- **BackgroundPanel** → Image resources (dependency)

### Application Entry
- **Main** → DatabaseInitializer, EnrollmentService, MainFrame (creates)

---

## Notes
- All model classes are immutable or have controlled mutability
- DAOs handle all database operations using JDBC
- Service layer provides transaction management and business logic
- UI layer uses Swing components with custom background panels
- Separation of concerns is maintained across all layers
