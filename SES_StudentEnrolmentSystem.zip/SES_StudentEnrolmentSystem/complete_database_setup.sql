-- ============================================================
-- Student Enrollment System - Complete Database Setup Script
-- ============================================================
-- This script will:
-- 1. Create the database
-- 2. Create all required tables
-- 3. Insert sample data (students, courses, enrollments)
-- ============================================================

-- Create database
DROP DATABASE IF EXISTS student_enrollment_db;
CREATE DATABASE student_enrollment_db;
USE student_enrollment_db;

-- ============================================================
-- Create students table
-- ============================================================
CREATE TABLE students (
    id VARCHAR(50) PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    surname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    date_of_birth VARCHAR(20) NOT NULL,
    programme VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Create courses table
-- ============================================================
CREATE TABLE courses (
    code VARCHAR(20) PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    credits INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Create enrollments table
-- ============================================================
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) NOT NULL,
    course_code VARCHAR(20) NOT NULL,
    semester VARCHAR(20) NOT NULL,
    grade_score DOUBLE DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (course_code) REFERENCES courses(code) ON DELETE CASCADE ON UPDATE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_code, semester),
    INDEX idx_student_id (student_id),
    INDEX idx_course_code (course_code),
    INDEX idx_semester (semester)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
-- Insert Sample Students
-- ============================================================
INSERT INTO students (id, first_name, surname, email, date_of_birth, programme) VALUES
('SE001001', 'John', 'Smith', 'john.smith@university.edu', '2000-05-15', 'Computer Science'),
('SE001002', 'Emma', 'Johnson', 'emma.johnson@university.edu', '2001-08-22', 'Software Engineering'),
('SE001003', 'Michael', 'Williams', 'michael.williams@university.edu', '1999-12-10', 'Computer Science'),
('SE001004', 'Sarah', 'Brown', 'sarah.brown@university.edu', '2000-03-18', 'Mathematics'),
('SE001005', 'David', 'Jones', 'david.jones@university.edu', '2001-07-25', 'Engineering'),
('SE001006', 'Lisa', 'Davis', 'lisa.davis@university.edu', '2000-11-30', 'Business'),
('SE001007', 'James', 'Miller', 'james.miller@university.edu', '2001-02-14', 'Psychology'),
('SE001008', 'Emily', 'Wilson', 'emily.wilson@university.edu', '2000-07-08', 'English & Literature'),
('SE001009', 'Daniel', 'Moore', 'daniel.moore@university.edu', '2001-09-20', 'Physics'),
('SE001010', 'Sophia', 'Taylor', 'sophia.taylor@university.edu', '2000-04-25', 'Nursing');

-- ============================================================
-- Insert Sample Courses - Computing & Data
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('CS101', 'Programming Fundamentals', 15),
('CS102', 'Data Structures & Algorithms', 15),
('CS103', 'Computer Systems & Organization', 15),
('CS104', 'Web Development Basics', 15),
('SE201', 'Software Engineering I', 15),
('DS301', 'Data Science Fundamentals', 15),
('AI301', 'Introduction to Artificial Intelligence', 15),
('CYB201', 'Foundations of Cybersecurity', 15),
('DB201', 'Databases & SQL', 15),
('NET201', 'Computer Networks', 15),
('HCI201', 'Human-Computer Interaction', 15),
('PROJ301', 'Team Software Project', 30);

-- ============================================================
-- Insert Sample Courses - Mathematics & Statistics
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('MATH101', 'Calculus I', 15),
('MATH102', 'Calculus II', 15),
('MATH103', 'Linear Algebra', 15),
('STAT101', 'Probability & Statistics', 15);

-- ============================================================
-- Insert Sample Courses - Natural Sciences
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('BIO101', 'General Biology I', 15),
('BIO102', 'General Biology II', 15),
('CHEM101', 'General Chemistry I', 15),
('CHEM102', 'General Chemistry II', 15),
('PHYS101', 'Physics I (Mechanics)', 15),
('PHYS102', 'Physics II (E&M)', 15),
('ENV101', 'Environmental Science', 15),
('GEO101', 'Physical Geography', 15);

-- ============================================================
-- Insert Sample Courses - Engineering
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('EE101', 'Circuits & Electronics', 15),
('ME101', 'Statics & Materials', 15),
('CE101', 'Introduction to Civil Engineering', 15),
('CHENG101', 'Principles of Chemical Engineering', 15);

-- ============================================================
-- Insert Sample Courses - Business & Management
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('BUS101', 'Introduction to Business', 15),
('ACCT101', 'Financial Accounting', 15),
('FIN101', 'Corporate Finance', 15),
('MKT101', 'Marketing Principles', 15),
('MGMT101', 'Organisational Behaviour', 15),
('OPS201', 'Operations & Supply Chain', 15),
('ENT201', 'Entrepreneurship', 15);

-- ============================================================
-- Insert Sample Courses - Social Sciences
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('ECON101', 'Microeconomics', 15),
('ECON102', 'Macroeconomics', 15),
('PSY101', 'Introduction to Psychology', 15),
('SOC101', 'Intro to Sociology', 15),
('POL101', 'Political Science: Institutions & Ideas', 15),
('GEO101', 'Physical Geography', 15);

-- ============================================================
-- Insert Sample Courses - Arts & Humanities
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('ENG101', 'Academic Writing & Composition', 15),
('LIT101', 'Introduction to Literature', 15),
('HIST101', 'World History', 15),
('PHIL101', 'Introduction to Philosophy', 15),
('LANG101', 'Modern Language I', 15),
('ART101', 'Foundations of Drawing & Design', 15),
('MUS101', 'Music Theory & Aural Skills', 15);

-- ============================================================
-- Insert Sample Courses - Law & Education
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('LAW101', 'Foundations of Law', 15),
('CRIM101', 'Introduction to Criminology', 15),
('EDU101', 'Foundations of Education', 15);

-- ============================================================
-- Insert Sample Courses - Media & Communication
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('JOUR101', 'News Writing & Reporting', 15),
('COMM101', 'Introduction to Communication', 15);

-- ============================================================
-- Insert Sample Courses - Health & Life Sciences
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('NURS101', 'Fundamentals of Nursing', 15),
('MEDSCI101', 'Human Anatomy & Physiology', 15),
('PUBH101', 'Public Health Principles', 15);

-- ============================================================
-- Insert Sample Courses - Agriculture & Environment
-- ============================================================
INSERT INTO courses (code, title, credits) VALUES
('AGRI101', 'Principles of Agriculture', 15);

-- ============================================================
-- Insert Sample Enrollments
-- ============================================================
INSERT INTO enrollments (student_id, course_code, semester, grade_score) VALUES
-- John Smith (Computer Science) - 2024-S1
('SE001001', 'CS101', '2024-S1', 85.5),
('SE001001', 'MATH101', '2024-S1', 78.0),
('SE001001', 'ENG101', '2024-S1', 72.5),

-- John Smith (Computer Science) - 2024-S2
('SE001001', 'CS102', '2024-S2', 88.0),
('SE001001', 'MATH102', '2024-S2', 81.5),
('SE001001', 'PHYS101', '2024-S2', 75.0),

-- John Smith (Computer Science) - 2025-S1 (current semester, no grades yet)
('SE001001', 'DB201', '2025-S1', NULL),
('SE001001', 'SE201', '2025-S1', NULL),

-- Emma Johnson (Software Engineering) - 2024-S1
('SE001002', 'CS101', '2024-S1', 92.0),
('SE001002', 'MATH101', '2024-S1', 85.0),
('SE001002', 'ENG101', '2024-S1', 88.5),

-- Emma Johnson (Software Engineering) - 2024-S2
('SE001002', 'CS102', '2024-S2', 90.5),
('SE001002', 'SE201', '2024-S2', 87.0),

-- Emma Johnson (Software Engineering) - 2025-S1 (current semester)
('SE001002', 'DB201', '2025-S1', NULL),
('SE001002', 'NET201', '2025-S1', NULL),

-- Michael Williams (Computer Science) - 2024-S1
('SE001003', 'CS101', '2024-S1', 76.0),
('SE001003', 'MATH101', '2024-S1', 70.5),

-- Michael Williams (Computer Science) - 2025-S1
('SE001003', 'CS102', '2025-S1', NULL),
('SE001003', 'PHYS101', '2025-S1', NULL),

-- Sarah Brown (Mathematics) - 2024-S1
('SE001004', 'MATH101', '2024-S1', 95.0),
('SE001004', 'PHYS101', '2024-S1', 89.0),
('SE001004', 'CS101', '2024-S1', 82.5),

-- Sarah Brown (Mathematics) - 2024-S2
('SE001004', 'MATH102', '2024-S2', 93.5),
('SE001004', 'MATH103', '2024-S2', 91.0),

-- David Jones (Engineering) - 2024-S1
('SE001005', 'MATH101', '2024-S1', 80.0),
('SE001005', 'PHYS101', '2024-S1', 83.5),
('SE001005', 'EE101', '2024-S1', 76.0),

-- David Jones (Engineering) - 2025-S1
('SE001005', 'ME101', '2025-S1', NULL),
('SE001005', 'MATH102', '2025-S1', NULL),

-- Lisa Davis (Business) - 2024-S1
('SE001006', 'BUS101', '2024-S1', 88.0),
('SE001006', 'ACCT101', '2024-S1', 85.5),
('SE001006', 'ENG101', '2024-S1', 79.0),

-- Lisa Davis (Business) - 2025-S1
('SE001006', 'FIN101', '2025-S1', NULL),
('SE001006', 'MKT101', '2025-S1', NULL),

-- James Miller (Psychology) - 2024-S1
('SE001007', 'PSY101', '2024-S1', 87.5),
('SE001007', 'SOC101', '2024-S1', 82.0),

-- Emily Wilson (English & Literature) - 2024-S1
('SE001008', 'ENG101', '2024-S1', 94.0),
('SE001008', 'LIT101', '2024-S1', 91.5),
('SE001008', 'HIST101', '2024-S1', 86.0),

-- Daniel Moore (Physics) - 2024-S1
('SE001009', 'PHYS101', '2024-S1', 90.0),
('SE001009', 'MATH101', '2024-S1', 88.5),
('SE001009', 'CHEM101', '2024-S1', 84.0),

-- Sophia Taylor (Nursing) - 2024-S1
('SE001010', 'NURS101', '2024-S1', 89.0),
('SE001010', 'MEDSCI101', '2024-S1', 86.5),
('SE001010', 'BIO101', '2024-S1', 83.0);

-- ============================================================
-- Verify Setup
-- ============================================================
-- Show all tables
SHOW TABLES;

-- Display table structures
DESCRIBE students;
DESCRIBE courses;
DESCRIBE enrollments;

-- Display counts
SELECT 'Students' AS Table_Name, COUNT(*) AS Record_Count FROM students
UNION ALL
SELECT 'Courses', COUNT(*) FROM courses
UNION ALL
SELECT 'Enrollments', COUNT(*) FROM enrollments;

-- Display sample data
SELECT '=== SAMPLE STUDENTS ===' AS Info;
SELECT * FROM students LIMIT 5;

SELECT '=== SAMPLE COURSES ===' AS Info;
SELECT * FROM courses LIMIT 10;

SELECT '=== SAMPLE ENROLLMENTS ===' AS Info;
SELECT
    e.id,
    e.student_id,
    CONCAT(s.first_name, ' ', s.surname) AS student_name,
    e.course_code,
    c.title AS course_title,
    e.semester,
    e.grade_score
FROM enrollments e
JOIN students s ON e.student_id = s.id
JOIN courses c ON e.course_code = c.code
LIMIT 10;

-- ============================================================
-- Useful Queries for Testing
-- ============================================================

-- Get all enrollments for a specific student
-- SELECT
--     e.student_id,
--     CONCAT(s.first_name, ' ', s.surname) AS student_name,
--     e.course_code,
--     c.title AS course_title,
--     e.semester,
--     e.grade_score,
--     CASE
--         WHEN e.grade_score IS NULL THEN 'Not Graded'
--         WHEN e.grade_score >= 40 THEN 'PASS'
--         ELSE 'FAIL'
--     END AS status
-- FROM enrollments e
-- JOIN students s ON e.student_id = s.id
-- JOIN courses c ON e.course_code = c.code
-- WHERE e.student_id = 'SE001001'
-- ORDER BY e.semester, e.course_code;

-- Get all students enrolled in a specific course
-- SELECT
--     e.course_code,
--     c.title AS course_title,
--     e.student_id,
--     CONCAT(s.first_name, ' ', s.surname) AS student_name,
--     s.programme,
--     e.semester,
--     e.grade_score
-- FROM enrollments e
-- JOIN students s ON e.student_id = s.id
-- JOIN courses c ON e.course_code = c.code
-- WHERE e.course_code = 'CS101'
-- ORDER BY e.semester, s.surname;

-- Get students with completed courses (have grades)
-- SELECT
--     e.student_id,
--     CONCAT(s.first_name, ' ', s.surname) AS student_name,
--     e.course_code,
--     c.title AS course_title,
--     e.semester,
--     e.grade_score,
--     CASE
--         WHEN e.grade_score >= 40 THEN 'PASS'
--         ELSE 'FAIL'
--     END AS status
-- FROM enrollments e
-- JOIN students s ON e.student_id = s.id
-- JOIN courses c ON e.course_code = c.code
-- WHERE e.grade_score IS NOT NULL
-- ORDER BY e.student_id, e.semester;

-- ============================================================
-- Setup Complete!
-- ============================================================
SELECT '✓ Database setup completed successfully!' AS Status;
SELECT 'You can now use the Student Enrollment System application.' AS Message;
