import ses.database.DatabaseConnection;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestDatabaseConnection {
    public static void main(String[] args) {
        System.out.println("=== Testing Database Connection ===\n");

        try {
            // Test 1: Get connection
            System.out.println("Test 1: Attempting to connect to database...");
            Connection conn = DatabaseConnection.getConnection();

            if (conn != null && !conn.isClosed()) {
                System.out.println("✓ Connection successful!");
                System.out.println("  Database: " + conn.getCatalog());
                System.out.println("  URL: " + conn.getMetaData().getURL());
                System.out.println();

                // Test 2: Check if tables exist
                System.out.println("Test 2: Checking if tables exist...");
                Statement stmt = conn.createStatement();

                // Check students table
                try {
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM students");
                    if (rs.next()) {
                        System.out.println("✓ students table exists - " + rs.getInt("count") + " records");
                    }
                } catch (Exception e) {
                    System.out.println("✗ students table does NOT exist or is empty");
                }

                // Check courses table
                try {
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM courses");
                    if (rs.next()) {
                        System.out.println("✓ courses table exists - " + rs.getInt("count") + " records");
                    }
                } catch (Exception e) {
                    System.out.println("✗ courses table does NOT exist or is empty");
                }

                // Check enrollments table
                try {
                    ResultSet rs = stmt.executeQuery("SELECT COUNT(*) as count FROM enrollments");
                    if (rs.next()) {
                        System.out.println("✓ enrollments table exists - " + rs.getInt("count") + " records");
                    }
                } catch (Exception e) {
                    System.out.println("✗ enrollments table does NOT exist or is empty");
                }

                System.out.println();
                System.out.println("Test 3: Displaying sample students...");
                ResultSet rs = stmt.executeQuery("SELECT * FROM students LIMIT 5");
                while (rs.next()) {
                    System.out.println("  - " + rs.getString("id") + ": " +
                                     rs.getString("first_name") + " " +
                                     rs.getString("surname") + " (" +
                                     rs.getString("programme") + ")");
                }

                DatabaseConnection.closeConnection(conn);
                System.out.println("\n✓ All tests completed successfully!");

            } else {
                System.out.println("✗ Connection failed!");
            }

        } catch (Exception e) {
            System.out.println("\n✗ ERROR: " + e.getMessage());
            System.out.println("\nPossible issues:");
            System.out.println("  1. MySQL server is not running");
            System.out.println("  2. Database 'student_enrollment_db' doesn't exist");
            System.out.println("  3. Username or password is incorrect");
            System.out.println("  4. MySQL JDBC driver is not in classpath");
            System.out.println("\nTo fix:");
            System.out.println("  1. Start MySQL: net start MySQL80");
            System.out.println("  2. Run complete_database_setup.sql in MySQL Workbench");
            System.out.println("  3. Verify password is: clickCLICK11@");
            e.printStackTrace();
        }
    }
}
