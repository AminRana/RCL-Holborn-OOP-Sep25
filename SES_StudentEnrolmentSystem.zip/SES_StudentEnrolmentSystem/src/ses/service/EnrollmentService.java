package ses.service;

import ses.dao.CourseDAO;
import ses.dao.EnrollmentDAO;
import ses.dao.StudentDAO;
import ses.model.Course;
import ses.model.Enrollment;
import ses.model.Grade;
import ses.model.Student;

import java.sql.SQLException;
import java.util.List;

public class EnrollmentService {

    private final StudentDAO studentDAO = new StudentDAO();
    private final CourseDAO courseDAO = new CourseDAO();
    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();

    public Student registerStudent(String id, String firstName, String surname, String email, String dateOfBirth, String programme) {
        try {
            if (studentDAO.studentExists(id)) {
                throw new IllegalStateException("Student ID already exists");
            }
            Student student = new Student(id, firstName, surname, email, dateOfBirth, programme);
            studentDAO.addStudent(student);
            return student;
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public void addCourse(String code, String title, int credits) {
        try {
            if (courseDAO.courseExists(code)) {
                throw new IllegalStateException("Course code already exists");
            }
            Course course = new Course(code, title, credits);
            courseDAO.addCourse(course);
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public List<Course> getAllCourses() {
        try {
            return courseDAO.getAllCourses();
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }



    public Enrollment enrolStudent(String studentId, String courseCode, String semester) {
        try {
            Student student = studentDAO.getStudentById(studentId);
            Course course = courseDAO.getCourseByCode(courseCode);

            if (student == null) throw new IllegalArgumentException("Student not found");
            if (course == null) throw new IllegalArgumentException("Course not found");

            if (enrollmentDAO.enrollmentExists(studentId, courseCode, semester)) {
                throw new IllegalStateException("Student already enrolled in this course for this semester.");
            }

            Enrollment enrollment = new Enrollment(student, course, semester);
            enrollmentDAO.addEnrollment(enrollment);
            return enrollment;
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }


    public void recordGrade(String studentId, String courseCode, String semester, double score) {
        try {
            if (!enrollmentDAO.enrollmentExists(studentId, courseCode, semester)) {
                throw new IllegalArgumentException("Enrollment not found");
            }
            Grade grade = new Grade(score);
            enrollmentDAO.updateGrade(studentId, courseCode, semester, score);
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public Student getStudentById(String studentId) {
        try {
            return studentDAO.getStudentById(studentId);
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public String getNextStudentId() {
        try {
            return studentDAO.getNextStudentId();
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public List<Enrollment> getStudentReport(String studentId) {
        try {
            return enrollmentDAO.getEnrollmentsByStudent(studentId);
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public List<Student> getAllStudents() {
        try {
            return studentDAO.getAllStudents();
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }



    public List<Enrollment> getAllEnrollments() {
        try {
            return enrollmentDAO.getAllEnrollments();
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }

    public void updateStudent(String id, String firstName, String surname, String email, String dateOfBirth, String programme) {
        try {
            Student student = studentDAO.getStudentById(id);
            if (student == null) {
                throw new IllegalArgumentException("Student not found");
            }
            Student updatedStudent = new Student(id, firstName, surname, email, dateOfBirth, programme);
            studentDAO.updateStudent(updatedStudent);
        } catch (SQLException e) {
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        }
    }
}