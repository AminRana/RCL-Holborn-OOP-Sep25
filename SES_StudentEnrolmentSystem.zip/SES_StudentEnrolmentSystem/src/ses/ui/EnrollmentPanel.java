package ses.ui;

import ses.model.Enrollment;
import ses.service.EnrollmentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class EnrollmentPanel extends JPanel {

    private final EnrollmentService service;
    private JTextField studentIdField;
    private JComboBox<String> departmentComboBox, courseComboBox, semesterComboBox, yearComboBox;
    private DefaultTableModel tableModel;
    private BackgroundPanel enrollmentBg;

    public EnrollmentPanel(EnrollmentService service) {
        this.service = service;
        initializeUI();
    }

    private void initializeUI() {
        // Wrap Enrollment area in BackgroundPanel so a per-screen background can be used
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        enrollmentBg = new BackgroundPanel("/icons/enrollment_management_bg.png", BackgroundPanel.Mode.SCALE);
        enrollmentBg.setLayout(new BorderLayout(10, 10));
        enrollmentBg.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel titleLabel = new JLabel("Enrollment Management", SwingConstants.CENTER);
        titleLabel.setFont(UIFont.APP_TITLE);
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        titleLabel.setOpaque(false);
        enrollmentBg.add(titleLabel, BorderLayout.NORTH);

        // Input and table panels (transparent so background shows through)
        JPanel inputPanel = createInputPanel();
        inputPanel.setOpaque(false);
        enrollmentBg.add(inputPanel, BorderLayout.WEST);

        JPanel tablePanel = createTablePanel();
        tablePanel.setOpaque(false);
        enrollmentBg.add(tablePanel, BorderLayout.CENTER);

        add(enrollmentBg, BorderLayout.CENTER);

        // Debug: print whether the background loaded from classpath/file or fallback
        System.out.println("EnrollmentPanel: external image loaded? " + enrollmentBg.isExternalImageLoaded());

        // Ctrl+E toggles the enrollment background visibility at runtime for quick testing
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control E"), "toggleEnrollmentBg");
        getActionMap().put("toggleEnrollmentBg", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                enrollmentBg.setShowBackground(!enrollmentBg.isShowBackground());
                System.out.println("EnrollmentPanel: showBackground=" + enrollmentBg.isShowBackground());
            }
        });
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Enroll Student in Course"));
        panel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Student ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Student ID:"), gbc);
        gbc.gridx = 1;
        studentIdField = new JTextField(15);
        studentIdField.setFont(UIFont.INPUT);
        studentIdField.setBackground(new Color(255,255,255,200));
        studentIdField.setOpaque(true);
        panel.add(studentIdField, gbc);

        // Department
        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Department:"), gbc);
        gbc.gridx = 1;
        String[] departments = {
            "Arts & Humanities",
            "Social Sciences",
            "Business & Management",
            "Computing & Data",
            "Engineering",
            "Natural Sciences",
            "Health & Life Sciences",
            "Law & Education",
            "Media & Communication",
            "Agriculture & Environmental Studies"
        };
        departmentComboBox = new JComboBox<>(departments);
        departmentComboBox.setFont(UIFont.INPUT);
        departmentComboBox.setOpaque(true);
        departmentComboBox.setBackground(new Color(255,255,255,200));
        departmentComboBox.addActionListener(e -> updateCourseList());
        panel.add(departmentComboBox, gbc);

        // Course
        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Course:"), gbc);
        gbc.gridx = 1;
        courseComboBox = new JComboBox<>();
        courseComboBox.setFont(UIFont.INPUT);
        courseComboBox.setOpaque(true);
        courseComboBox.setBackground(new Color(255,255,255,200));
        panel.add(courseComboBox, gbc);

        // Semester
        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Semester:"), gbc);
        gbc.gridx = 1;
        String[] semesters = {"1", "2"};
        semesterComboBox = new JComboBox<>(semesters);
        semesterComboBox.setFont(UIFont.INPUT);
        semesterComboBox.setOpaque(true);
        semesterComboBox.setBackground(new Color(255,255,255,200));
        panel.add(semesterComboBox, gbc);

        // Year
        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Year:"), gbc);
        gbc.gridx = 1;
        // Generate years from 2020 to 2030
        String[] years = new String[11];
        for (int i = 0; i < 11; i++) {
            years[i] = String.valueOf(2020 + i);
        }
        yearComboBox = new JComboBox<>(years);
        yearComboBox.setFont(UIFont.INPUT);
        yearComboBox.setOpaque(true);
        yearComboBox.setBackground(new Color(255,255,255,200));
        yearComboBox.setSelectedItem("2025"); // Default to 2025
        panel.add(yearComboBox, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);

        JButton enrollButton = new JButton("Enroll Student");
        enrollButton.setFont(UIFont.BUTTON);
        enrollButton.addActionListener(e -> enrollStudent());
        buttonPanel.add(enrollButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setFont(UIFont.BUTTON);
        clearButton.addActionListener(e -> clearFields());
        buttonPanel.add(clearButton);

        panel.add(buttonPanel, gbc);

        // Initialize course list with first department
        updateCourseList();

        return panel;
    }

    private void updateCourseList() {
        courseComboBox.removeAllItems();

        String[][] coursesByDepartment = {
            // Arts & Humanities
            {
                "ENG101 - Academic Writing & Composition",
                "LIT101 - Introduction to Literature",
                "HIST101 - World History",
                "PHIL101 - Introduction to Philosophy",
                "LANG101 - Modern Language I",
                "ART101 - Foundations of Drawing & Design",
                "MUS101 - Music Theory & Aural Skills"
            },
            // Social Sciences
            {
                "PSY101 - Introduction to Psychology",
                "SOC101 - Intro to Sociology",
                "POL101 - Political Science: Institutions & Ideas",
                "ECON101 - Microeconomics",
                "ECON102 - Macroeconomics",
                "GEO101 - Physical Geography"
            },
            // Business & Management
            {
                "ACCT101 - Financial Accounting",
                "FIN101 - Corporate Finance",
                "MKT101 - Marketing Principles",
                "BUS101 - Introduction to Business",
                "MGMT101 - Organisational Behaviour",
                "OPS201 - Operations & Supply Chain",
                "ENT201 - Entrepreneurship"
            },
            // Computing & Data
            {
                "CS101 - Programming Fundamentals",
                "CS102 - Data Structures & Algorithms",
                "CS103 - Computer Systems & Organization",
                "CS104 - Web Development Basics",
                "SE201 - Software Engineering I",
                "DS301 - Data Science Fundamentals",
                "AI301 - Introduction to Artificial Intelligence",
                "CYB201 - Foundations of Cybersecurity",
                "DB201 - Databases & SQL",
                "NET201 - Computer Networks",
                "HCI201 - Human-Computer Interaction",
                "PROJ301 - Team Software Project"
            },
            // Engineering
            {
                "EE101 - Circuits & Electronics",
                "ME101 - Statics & Materials",
                "CE101 - Introduction to Civil Engineering",
                "CHENG101 - Principles of Chemical Engineering"
            },
            // Natural Sciences
            {
                "MATH101 - Calculus I",
                "MATH102 - Calculus II",
                "MATH103 - Linear Algebra",
                "STAT101 - Probability & Statistics",
                "PHYS101 - Physics I (Mechanics)",
                "PHYS102 - Physics II (E&M)",
                "CHEM101 - General Chemistry I",
                "CHEM102 - General Chemistry II",
                "BIO101 - General Biology I",
                "BIO102 - General Biology II",
                "ENV101 - Environmental Science"
            },
            // Health & Life Sciences
            {
                "NURS101 - Fundamentals of Nursing",
                "MEDSCI101 - Human Anatomy & Physiology",
                "PUBH101 - Public Health Principles"
            },
            // Law & Education
            {
                "LAW101 - Foundations of Law",
                "CRIM101 - Introduction to Criminology",
                "EDU101 - Foundations of Education"
            },
            // Media & Communication
            {
                "JOUR101 - News Writing & Reporting",
                "COMM101 - Introduction to Communication"
            },
            // Agriculture & Environmental Studies
            {
                "AGRI101 - Principles of Agriculture"
            }
        };

        int departmentIndex = departmentComboBox.getSelectedIndex();
        if (departmentIndex >= 0 && departmentIndex < coursesByDepartment.length) {
            for (String course : coursesByDepartment[departmentIndex]) {
                courseComboBox.addItem(course);
            }
        }
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Current Enrollments"));
        panel.setOpaque(false);

        // Create table
        String[] columnNames = {"Student ID", "Student Name", "Course Code", "Course Title", "Semester", "Grade"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable enrollmentTable = new JTable(tableModel);
        enrollmentTable.setFont(UIFont.TABLE_TEXT);
        // make table transparent so background shows through
        enrollmentTable.setOpaque(false);
        enrollmentTable.setBackground(new Color(0,0,0,0));
        enrollmentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // semi-transparent row backgrounds
        enrollmentTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    Color even = new Color(255,255,255,160);
                    Color odd = new Color(255,255,255,80);
                    c.setBackground(row % 2 == 0 ? even : odd);
                }
                setBorder(BorderFactory.createEmptyBorder(4,8,4,8));
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(enrollmentTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0,0,0,0));
        panel.add(scrollPane, BorderLayout.CENTER);

        // Refresh button
        JButton refreshButton = new JButton("Refresh List");
        refreshButton.setFont(UIFont.BUTTON);
        refreshButton.addActionListener(e -> refreshTable());
        JPanel south = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        south.setOpaque(false);
        south.add(refreshButton);
        panel.add(south, BorderLayout.SOUTH);

        return panel;
    }

    private void enrollStudent() {
        try {
            String studentId = studentIdField.getText().trim();
            String courseSelection = (String) courseComboBox.getSelectedItem();
            String semesterNum = (String) semesterComboBox.getSelectedItem();
            String year = (String) yearComboBox.getSelectedItem();

            if (studentId.isEmpty() || courseSelection == null || semesterNum == null || year == null) {
                JOptionPane.showMessageDialog(this,
                        "All fields are required!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Extract course code from selection (e.g., "CS101 - Programming Fundamentals" -> "CS101")
            String courseCode = courseSelection.split(" - ")[0];

            // Build semester string (e.g., "2025-S1")
            String semester = year + "-S" + semesterNum;

            Enrollment enrollment = service.enrolStudent(studentId, courseCode, semester);

            // Add to table
            String gradeInfo = enrollment.getGrade() != null
                    ? String.valueOf(enrollment.getGrade().getScore())
                    : "N/A";

            tableModel.addRow(new Object[]{
                    enrollment.getStudent().getId(),
                    enrollment.getStudent().getFullName(),
                    enrollment.getCourse().getCode(),
                    enrollment.getCourse().getTitle(),
                    enrollment.getSemester(),
                    gradeInfo
            });

            JOptionPane.showMessageDialog(this,
                    "Student enrolled successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Enrollment Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        studentIdField.setText("");
        departmentComboBox.setSelectedIndex(0);
        updateCourseList();
        semesterComboBox.setSelectedIndex(0);
        yearComboBox.setSelectedItem("2025");
        studentIdField.requestFocus();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        try {
            for (ses.model.Enrollment enrollment : service.getAllEnrollments()) {
                String gradeInfo = enrollment.getGrade() != null
                        ? String.valueOf(enrollment.getGrade().getScore())
                        : "N/A";

                tableModel.addRow(new Object[]{
                        enrollment.getStudent().getId(),
                        enrollment.getStudent().getFullName(),
                        enrollment.getCourse().getCode(),
                        enrollment.getCourse().getTitle(),
                        enrollment.getSemester(),
                        gradeInfo
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error refreshing table: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
