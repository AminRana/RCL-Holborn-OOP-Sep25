package ses.ui;

import ses.model.Enrollment;
import ses.service.EnrollmentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

/**
 * ReportPanel provides a comprehensive student report interface.
 * Displays student information, all enrollments with grades, and summary statistics.
 * Shows data in a table-based format for easy reading.
 */
public class ReportPanel extends JPanel {

    // Service for accessing enrollment and student data
    private final EnrollmentService service;

    // Per-panel background so this report view can have its own image
    private BackgroundPanel reportBg;

    // UI Components
    private JTextField studentIdField;              // Input field for student ID
    private JPanel reportDisplayPanel;              // Main panel for displaying report
    private JLabel studentInfoLabel;                // Label showing student details
    private JTable enrollmentsTable;                // Table showing all enrollments
    private DefaultTableModel enrollmentsTableModel; // Data model for enrollments table
    private JTable statsTable;                      // Table showing summary statistics
    private DefaultTableModel statsTableModel;      // Data model for statistics table

    /**
     * Constructor to create the ReportPanel.
     *
     * @param service The EnrollmentService for accessing student and enrollment data
     */
    public ReportPanel(EnrollmentService service) {
        this.service = service;
        initializeUI();
    }

    /**
     * Initializes the user interface components.
     * Sets up the layout with title, search input, and report display area.
     */
    private void initializeUI() {
        // Wrap the Report UI in a BackgroundPanel so it can have its own background image
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        reportBg = new BackgroundPanel("/icons/reports_bg.png", BackgroundPanel.Mode.SCALE);
        reportBg.setLayout(new BorderLayout(10, 10));
        reportBg.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create a top panel (title + input) so Generate Report stays at the top
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);

        JLabel titleLabel = new JLabel("Student Report", SwingConstants.CENTER);
        titleLabel.setFont(UIFont.APP_TITLE);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        titleLabel.setOpaque(false);
        topPanel.add(titleLabel, BorderLayout.NORTH);

        // Input Panel for searching students (transparent)
        JPanel inputPanel = createInputPanel();
        inputPanel.setOpaque(false);
        topPanel.add(inputPanel, BorderLayout.CENTER);

        reportBg.add(topPanel, BorderLayout.NORTH);

        // Report Display Area (shows student info, enrollments, and statistics)
        reportDisplayPanel = createReportDisplayPanel();
        reportDisplayPanel.setOpaque(false);
        reportBg.add(reportDisplayPanel, BorderLayout.CENTER);

        add(reportBg, BorderLayout.CENTER);

        // Debug and runtime toggle: print whether external image loaded, and bind Ctrl+R to toggle
        System.out.println("ReportPanel: external image loaded? " + reportBg.isExternalImageLoaded());
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control R"), "toggleReportBg");
        getActionMap().put("toggleReportBg", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                reportBg.setShowBackground(!reportBg.isShowBackground());
                System.out.println("ReportPanel: showBackground=" + reportBg.isShowBackground());
            }
        });
    }

    /**
     * Creates the input panel with student ID field and action buttons.
     *
     * @return JPanel containing search controls
     */
    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(BorderFactory.createTitledBorder("Search Student"));
        panel.setOpaque(false);

        // Student ID label and input field
        panel.add(new JLabel("Student ID:"));
        studentIdField = new JTextField(20);
        studentIdField.setBackground(new Color(255,255,255,200));
        studentIdField.setOpaque(true);
        panel.add(studentIdField);

        // Generate Report button - triggers report generation
        JButton searchButton = new JButton("Generate Report");
        searchButton.addActionListener(e -> generateReport());
        panel.add(searchButton);

        // Clear button - resets the form
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> clearReport());
        panel.add(clearButton);

        return panel;
    }

    private JPanel createReportDisplayPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createTitledBorder("Report Details"));
        panel.setOpaque(false);

        // Student Info Panel
        JPanel studentInfoPanel = new JPanel(new BorderLayout());
        studentInfoPanel.setBorder(BorderFactory.createTitledBorder("Student Information"));
        studentInfoPanel.setOpaque(false);
        studentInfoLabel = new JLabel("<html><body style='padding: 10px;'>No report generated yet. Enter a Student ID and click 'Generate Report'.</body></html>");
        studentInfoLabel.setFont(UIFont.LABEL);
        studentInfoLabel.setForeground(Color.WHITE);
        studentInfoLabel.setOpaque(true);
        studentInfoLabel.setBackground(new Color(0, 0, 0, 180));
        studentInfoPanel.add(studentInfoLabel, BorderLayout.CENTER);

        // Enrollments Table
        JPanel enrollmentsPanel = new JPanel(new BorderLayout());
        enrollmentsPanel.setBorder(BorderFactory.createTitledBorder("Course Enrollments & Grades"));
        enrollmentsPanel.setOpaque(false);

        String[] enrollmentColumns = {"#", "Course Code", "Course Title", "Semester", "Grade", "Status"};
        enrollmentsTableModel = new DefaultTableModel(enrollmentColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        enrollmentsTable = new JTable(enrollmentsTableModel);
        // make table transparent so background shows through
        enrollmentsTable.setOpaque(false);
        enrollmentsTable.setBackground(new Color(0,0,0,0));
        enrollmentsTable.setFont(UIFont.TABLE_TEXT);
        enrollmentsTable.setRowHeight(25);
        enrollmentsTable.getTableHeader().setFont(UIFont.TABLE_HEADER);

        // semi-transparent rows for readability
        enrollmentsTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    Color even = new Color(255,255,255, 255);
                    Color odd = new Color(255,255,255, 255);
                    c.setBackground(row % 2 == 0 ? even : odd);
                    setForeground(Color.BLACK);
                } else {
                    setForeground(Color.WHITE);
                }
                setBorder(BorderFactory.createEmptyBorder(4,8,4,8));
                return c;
            }
        });

        JScrollPane enrollmentsScrollPane = new JScrollPane(enrollmentsTable);
        enrollmentsScrollPane.setOpaque(false);
        enrollmentsScrollPane.getViewport().setOpaque(false);
        enrollmentsScrollPane.getViewport().setBackground(new Color(0,0,0,0));
        enrollmentsPanel.add(enrollmentsScrollPane, BorderLayout.CENTER);

        // Statistics Table
        JPanel statsPanel = new JPanel(new BorderLayout());
        statsPanel.setBorder(BorderFactory.createTitledBorder("Summary Statistics"));
        statsPanel.setOpaque(false);

        String[] statsColumns = {"Metric", "Value"};
        statsTableModel = new DefaultTableModel(statsColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        statsTable = new JTable(statsTableModel);
        statsTable.setOpaque(false);
        statsTable.setBackground(new Color(0,0,0,0));
        statsTable.setFont(UIFont.TABLE_TEXT);
        statsTable.setRowHeight(25);
        statsTable.getTableHeader().setFont(UIFont.TABLE_HEADER);

        // Make stats table text readable with white background
        statsTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(new Color(255,255,255, 255));
                    setForeground(Color.BLACK);
                } else {
                    setForeground(Color.WHITE);
                }
                setBorder(BorderFactory.createEmptyBorder(4,8,4,8));
                return c;
            }
        });

        JScrollPane statsScrollPane = new JScrollPane(statsTable);
        statsScrollPane.setOpaque(false);
        statsScrollPane.getViewport().setOpaque(false);
        statsScrollPane.getViewport().setBackground(new Color(0,0,0,0));
        statsScrollPane.setPreferredSize(new Dimension(400, 200));
        statsPanel.add(statsScrollPane, BorderLayout.CENTER);

        // Layout: Student Info at top, Enrollments in center, Stats at bottom
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setOpaque(false);
        mainPanel.add(studentInfoPanel, BorderLayout.NORTH);
        mainPanel.add(enrollmentsPanel, BorderLayout.CENTER);
        mainPanel.add(statsPanel, BorderLayout.SOUTH);

        panel.add(mainPanel, BorderLayout.CENTER);

        return panel;
    }

    /**
     * Generates a comprehensive report for the specified student.
     * Fetches student information, enrollments, and calculates statistics.
     * Displays all data in tables for easy viewing.
     */
    private void generateReport() {
        try {
            // Get and validate student ID input
            String studentId = studentIdField.getText().trim();

            // Validate that student ID is not empty
            if (studentId.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter a Student ID!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Step 1: Fetch student information from database
            ses.model.Student student = service.getStudentById(studentId);

            // Check if student exists
            if (student == null) {
                // Student not found - display error message and clear tables
                studentInfoLabel.setText("<html><body style='padding: 10px;'><b>No student found with ID: " + studentId + "</b></body></html>");
                enrollmentsTableModel.setRowCount(0);
                statsTableModel.setRowCount(0);
                return;
            }

            // Step 2: Build and display student information as HTML table
            StringBuilder studentInfo = new StringBuilder();
            studentInfo.append("<html><body style='padding: 10px;'>");
            studentInfo.append("<table cellpadding='5'>");
            studentInfo.append("<tr><td><b>Student ID:</b></td><td>").append(student.getId()).append("</td></tr>");
            studentInfo.append("<tr><td><b>First Name:</b></td><td>").append(student.getFirstName()).append("</td></tr>");
            studentInfo.append("<tr><td><b>Surname:</b></td><td>").append(student.getSurname()).append("</td></tr>");
            studentInfo.append("<tr><td><b>Full Name:</b></td><td>").append(student.getFullName()).append("</td></tr>");
            studentInfo.append("<tr><td><b>Email:</b></td><td>").append(student.getEmail()).append("</td></tr>");
            studentInfo.append("<tr><td><b>Date of Birth:</b></td><td>").append(student.getDateOfBirth()).append("</td></tr>");
            studentInfo.append("<tr><td><b>Programme:</b></td><td>").append(student.getProgramme()).append("</td></tr>");
            studentInfo.append("</table>");
            studentInfo.append("</body></html>");
            studentInfoLabel.setText(studentInfo.toString());

            // Step 3: Fetch all enrollments for this student
            List<Enrollment> enrollments = service.getStudentReport(studentId);

            // Clear previous data from tables
            enrollmentsTableModel.setRowCount(0);
            statsTableModel.setRowCount(0);

            // Step 4: Populate enrollments table with course data
            if (enrollments.isEmpty()) {
                // No enrollments found - display message in table
                enrollmentsTableModel.addRow(new Object[]{"", "", "No enrollments found for this student", "", "", ""});
            } else {
                // Loop through each enrollment and add to table
                int courseNumber = 1;
                for (Enrollment enrollment : enrollments) {
                    String gradeStr;
                    String status;

                    // Check if enrollment has been graded
                    if (enrollment.getGrade() != null) {
                        // Format grade score to 2 decimal places
                        gradeStr = String.format("%.2f", enrollment.getGrade().getScore());
                        // Determine pass/fail status
                        status = enrollment.getGrade().isPass() ? "✓ PASS" : "✗ FAIL";
                    } else {
                        // Not yet graded
                        gradeStr = "N/A";
                        status = "In Progress";
                    }

                    // Add row to table with all enrollment details
                    enrollmentsTableModel.addRow(new Object[]{
                            courseNumber++,                      // Row number
                            enrollment.getCourse().getCode(),    // Course code
                            enrollment.getCourse().getTitle(),   // Course title
                            enrollment.getSemester(),            // Semester
                            gradeStr,                            // Grade score
                            status                               // Pass/Fail/In Progress
                    });
                }
            }

            // Step 5: Calculate summary statistics using Java Streams
            int totalEnrollments = enrollments.size();

            // Count completed courses (those with grades)
            long completedCourses = enrollments.stream().filter(e -> e.getGrade() != null).count();

            // Count passed courses (grade exists and is passing)
            long passedCourses = enrollments.stream()
                    .filter(e -> e.getGrade() != null && e.getGrade().isPass())
                    .count();

            // Count failed courses (grade exists but is failing)
            long failedCourses = enrollments.stream()
                    .filter(e -> e.getGrade() != null && !e.getGrade().isPass())
                    .count();

            // Count in-progress courses (no grade yet)
            long inProgressCourses = enrollments.stream().filter(e -> e.getGrade() == null).count();

            // Calculate average grade for completed courses only
            double averageGrade = enrollments.stream()
                    .filter(e -> e.getGrade() != null)  // Only graded courses
                    .mapToDouble(e -> e.getGrade().getScore())  // Extract scores
                    .average()  // Calculate average
                    .orElse(0.0);  // Default to 0 if no graded courses

            // Step 6: Populate statistics table with calculated values
            statsTableModel.addRow(new Object[]{"Total Enrollments", totalEnrollments});
            statsTableModel.addRow(new Object[]{"Completed Courses", completedCourses});
            statsTableModel.addRow(new Object[]{"Passed Courses", passedCourses});
            statsTableModel.addRow(new Object[]{"Failed Courses", failedCourses});
            statsTableModel.addRow(new Object[]{"In Progress", inProgressCourses});
            // Only show average if there are completed courses
            if (completedCourses > 0) {
                statsTableModel.addRow(new Object[]{"Average Grade", String.format("%.2f", averageGrade)});
            }

        } catch (Exception ex) {
            // Handle any errors during report generation
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Report Generation Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Clears the report and resets all fields to initial state.
     * Removes all data from tables and resets the student info label.
     */
    private void clearReport() {
        // Clear the student ID input field
        studentIdField.setText("");

        // Reset student info label to default message
        studentInfoLabel.setText("<html><body style='padding: 10px;'>No report generated yet. Enter a Student ID and click 'Generate Report'.</body></html>");

        // Clear all rows from both tables
        enrollmentsTableModel.setRowCount(0);
        statsTableModel.setRowCount(0);

        // Set focus back to student ID field for next search
        studentIdField.requestFocus();
    }
}
