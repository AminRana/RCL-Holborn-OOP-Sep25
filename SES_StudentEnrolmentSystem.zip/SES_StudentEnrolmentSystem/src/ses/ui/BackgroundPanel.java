package ses.ui;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;

/**
 * Reusable panel that paints a background image. Supports SCALE (stretch to fill) and TILE modes.
 * Loads resources from the classpath (e.g. "/icons/bg.png") or falls back to a local resources folder.
 */
public class BackgroundPanel extends JPanel {

    public enum Mode { SCALE, TILE }

    private BufferedImage image;
    private BufferedImage scaledCache;
    private Dimension lastSize;
    private final Mode mode;
    private boolean showBackground = true;
    private boolean loadedFromExternal = false; // true when loaded from classpath or resources file

    public BackgroundPanel(String resourcePath, Mode mode) {
        this.mode = mode == null ? Mode.SCALE : mode;
        setLayout(new BorderLayout());
        loadImage(resourcePath);
    }

    public void setShowBackground(boolean show) {
        this.showBackground = show;
        repaint();
    }

    public boolean isShowBackground() {
        return showBackground;
    }

    /** Returns true when an actual image file was loaded from classpath or resources folder (not a generated fallback). */
    public boolean isExternalImageLoaded() {
        return loadedFromExternal;
    }

    private void loadImage(String resourcePath) {
        if (resourcePath == null) {
            System.out.println("BackgroundPanel: no resourcePath provided");
            return;
        }
        // Try classpath first
        try (InputStream is = getClass().getResourceAsStream(resourcePath)) {
            if (is != null) {
                image = ImageIO.read(is);
                loadedFromExternal = true;
                System.out.println("BackgroundPanel: loaded background from classpath: " + resourcePath);
                return;
            } else {
                System.out.println("BackgroundPanel: classpath resource not found: " + resourcePath);
            }
        } catch (IOException ex) {
            System.out.println("BackgroundPanel: error reading classpath resource: " + ex.getMessage());
        }

        // Fallback to a relative file under the project's resources folder
        try {
            String rel = "resources" + resourcePath;
            File f = new File(rel);
            if (f.exists()) {
                image = ImageIO.read(f);
                loadedFromExternal = true;
                System.out.println("BackgroundPanel: loaded background from file: " + f.getAbsolutePath());
            } else {
                System.out.println("BackgroundPanel: fallback file not found: " + f.getAbsolutePath());
            }
        } catch (IOException ex) {
            System.out.println("BackgroundPanel: error reading fallback file: " + ex.getMessage());
        }

        if (image == null) {
            System.out.println("BackgroundPanel: no background image loaded — generating a gradient fallback");
            // Generate a pleasing gradient fallback image so UI shows something immediately
            image = createGradientFallback(1600, 900);
        }
    }

    private BufferedImage createGradientFallback(int w, int h) {
        BufferedImage bi = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = bi.createGraphics();
        try {
            g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
            GradientPaint gp = new GradientPaint(0, 0, new Color(58, 123, 213), w, h, new Color(58, 213, 162));
            g2.setPaint(gp);
            g2.fillRect(0, 0, w, h);
            // add subtle overlay texture
            g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.06f));
            g2.setColor(Color.WHITE);
            for (int i = 0; i < w; i += 40) {
                g2.fillRect(i, 0, 2, h);
            }
        } finally {
            g2.dispose();
        }
        return bi;
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (!showBackground) {
            // draw plain background when disabled
            g.setColor(getBackground());
            g.fillRect(0, 0, getWidth(), getHeight());
            return;
        }

        if (image == null) return;

        Graphics2D g2 = (Graphics2D) g.create();
        try {
            if (mode == Mode.SCALE) {
                int w = getWidth();
                int h = getHeight();
                if (w <= 0 || h <= 0) return;
                if (scaledCache == null || lastSize == null || lastSize.width != w || lastSize.height != h) {
                    scaledCache = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                    Graphics2D gsc = scaledCache.createGraphics();
                    gsc.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
                    gsc.drawImage(image, 0, 0, w, h, null);
                    gsc.dispose();
                    lastSize = new Dimension(w, h);
                }
                g2.drawImage(scaledCache, 0, 0, null);
            } else { // TILE
                int iw = image.getWidth();
                int ih = image.getHeight();
                if (iw <= 0 || ih <= 0) return;
                for (int x = 0; x < getWidth(); x += iw) {
                    for (int y = 0; y < getHeight(); y += ih) {
                        g2.drawImage(image, x, y, this);
                    }
                }
            }
        } finally {
            g2.dispose();
        }
    }
}
