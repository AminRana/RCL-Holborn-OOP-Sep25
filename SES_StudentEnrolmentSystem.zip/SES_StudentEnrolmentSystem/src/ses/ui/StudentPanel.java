package ses.ui;

import ses.model.Student;
import ses.service.EnrollmentService;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Calendar;

/**
 * Modern StudentPanel with gradient header, card-style panels, and professional styling.
 * Features: Cool blue gradient header, warm neutral background, striped tables, rounded cards.
 */
public class StudentPanel extends JPanel {

    private final EnrollmentService service;
    private JTextField idField, firstNameField, surnameField, emailField, dobField;
    private JComboBox<String> programmeComboBox;
    private JTable studentTable;
    private DefaultTableModel tableModel;
    private CardLayout cardLayout;
    private JPanel contentPanel;

    // Profile management fields
    private JTextField searchIdField;
    private JTextField editFirstNameField, editSurnameField, editEmailField, editDobField;
    private JComboBox<String> editProgrammeComboBox;
    private JLabel profileIdLabel, profileFirstNameLabel, profileSurnameLabel, profileEmailLabel, profileDobLabel, profileProgrammeLabel;

    // Modern color palette
    private static final Color GRADIENT_START = new Color(52, 152, 219);  // Cool blue
    private static final Color GRADIENT_END = new Color(41, 128, 185);    // Darker blue
    private static final Color BACKGROUND_COLOR = new Color(245, 245, 245); // Warm neutral
    // Slightly more translucent card background so the student-management background image shows through more
    private static final Color CARD_BACKGROUND = new Color(255, 255, 255, 180);
    private static final Color TEXT_PRIMARY = new Color(44, 62, 80);
    private static final Color TEXT_SECONDARY = new Color(127, 140, 141);
    private static final Color ACCENT_COLOR = new Color(52, 152, 219);
    private static final Color TABLE_STRIPE = new Color(249, 249, 249);
    private static final Color TABLE_HEADER_BG = new Color(236, 240, 241);

    public StudentPanel(EnrollmentService service) {
        this.service = service;
        initializeUI();
    }

    private void initializeUI() {
        setLayout(new BorderLayout(0, 0));
        setBackground(BACKGROUND_COLOR);
        setOpaque(false); // allow outer background image to show through

        // Create gradient header panel
        JPanel headerPanel = createGradientHeader();
        //add(headerPanel, BorderLayout.NORTH);

        // Main content area with warm neutral background
        JPanel mainPanel = new JPanel(new BorderLayout(15, 15));
        mainPanel.setBackground(BACKGROUND_COLOR);
        mainPanel.setOpaque(false);
        mainPanel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        // Create menu panel
        JPanel menuPanel = createMenuPanel();
        menuPanel.setOpaque(false);
        mainPanel.add(menuPanel, BorderLayout.WEST);

        // Create content panel with CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setBackground(BACKGROUND_COLOR);
        contentPanel.setOpaque(false);

        // Add different panels
        contentPanel.add(createRegistrationPanel(), "registration");
        contentPanel.add(createProfileManagementPanel(), "profile");

        mainPanel.add(contentPanel, BorderLayout.CENTER);

        // Wrap header + main content in a BackgroundPanel so the whole Student area gets its own background
        BackgroundPanel studentBg = new BackgroundPanel("/icons/student_management_bg.png", BackgroundPanel.Mode.SCALE);
        studentBg.setLayout(new BorderLayout());
        studentBg.add(headerPanel, BorderLayout.NORTH);
        studentBg.add(mainPanel, BorderLayout.CENTER);
        // ensure the wrapper paints its background image
        studentBg.setOpaque(true);

        add(studentBg, BorderLayout.CENTER);

         // Show registration panel by default
         cardLayout.show(contentPanel, "registration");
    }

    /**
     * Creates a modern gradient header with cool blue colors
     */
    private JPanel createGradientHeader() {
        JPanel headerPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                // Create gradient from left to right
                GradientPaint gradient = new GradientPaint(
                    0, 0, GRADIENT_START,
                    getWidth(), 0, GRADIENT_END
                );
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, getWidth(), getHeight());
            }
        };

        headerPanel.setLayout(new BorderLayout());
        headerPanel.setPreferredSize(new Dimension(0, 80));

        // Title label with modern styling
        JLabel titleLabel = new JLabel("Student Management", SwingConstants.CENTER);
        titleLabel.setFont(UIFont.APP_TITLE);
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        headerPanel.add(titleLabel, BorderLayout.CENTER);

        return headerPanel;
    }

    private JPanel createMenuPanel() {
        // Card-style menu panel
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(CARD_BACKGROUND);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 1),
            BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        panel.setPreferredSize(new Dimension(220, 0));

        // Menu title
        JLabel menuTitle = new JLabel("Student Menu");
        menuTitle.setFont(UIFont.GROUP_HEADER);
        menuTitle.setForeground(TEXT_PRIMARY);
        menuTitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        // Modern styled buttons
        JButton registerButton = createStyledButton("Register");
        registerButton.addActionListener(e -> cardLayout.show(contentPanel, "registration"));

        JButton profileButton = createStyledButton("Profile Management");
        profileButton.addActionListener(e -> cardLayout.show(contentPanel, "profile"));

        panel.add(menuTitle);
        panel.add(Box.createRigidArea(new Dimension(0, 20)));
        panel.add(registerButton);
        panel.add(Box.createRigidArea(new Dimension(0, 12)));
        panel.add(profileButton);
        panel.add(Box.createVerticalGlue());

        return panel;
    }

    /**
     * Creates a modern styled button with consistent appearance
     */
    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(190, 42));
        button.setFont(UIFont.BUTTON);
        button.setForeground(TEXT_PRIMARY);
        button.setBackground(new Color(236, 240, 241));
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(ACCENT_COLOR);
                button.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(236, 240, 241));
                button.setForeground(TEXT_PRIMARY);
            }
        });

        return button;
    }

    private JPanel createRegistrationPanel() {
        // Custom panel with background image
        JPanel panel = new JPanel(new BorderLayout(15, 15)) {
            private BufferedImage backgroundImage;

            {
                // Try to load background image
                // Try classpath resource first (use try-with-resources to avoid leaks)
                try (java.io.InputStream is = getClass().getResourceAsStream("/icons/registration_background.png")) {
                    if (is != null) {
                        backgroundImage = ImageIO.read(is);
                    } else {
                        // Fallback to project resources folder
                        File f = new File("resources/images/registration_background.png");
                        if (f.exists()) {
                            backgroundImage = ImageIO.read(f);
                        } else {
                            backgroundImage = null;
                        }
                    }
                } catch (IOException e) {
                    backgroundImage = null;
                }
            }

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);

                if (backgroundImage != null) {
                    // Draw background image scaled to panel size
                    g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);

                    // Add a light translucent overlay so foreground cards remain readable
                    // but allow the student-management background to show through
                    g2d.setColor(new Color(245, 245, 245, 120)); // ~47% opacity
                    g2d.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        panel.setOpaque(false);

        // Input Panel (card style)
        JPanel inputPanel = createInputPanel();
        panel.add(inputPanel, BorderLayout.WEST);

        // Table Panel (card style)
        JPanel tablePanel = createTablePanel();
        panel.add(tablePanel, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createInputPanel() {
         // Card-style panel with white background and shadow effect
         JPanel cardPanel = new JPanel(new BorderLayout());
         // make the card panel transparent so the student-management background shows through
         cardPanel.setOpaque(false);
         cardPanel.setBorder(BorderFactory.createCompoundBorder(
             BorderFactory.createLineBorder(Color.BLACK, 1),
             BorderFactory.createEmptyBorder(16, 16, 16, 16)
         ));

         // Title panel with icon
         JPanel titlePanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
         titlePanel.setOpaque(false);

        // Try to load the student registration icon
        try {
            BufferedImage iconImage = ImageIO.read(new File("resources/icons/student_registration.png"));
            Image scaledIcon = iconImage.getScaledInstance(32, 32, Image.SCALE_SMOOTH);
            JLabel iconLabel = new JLabel(new ImageIcon(scaledIcon));
            titlePanel.add(iconLabel);
        } catch (IOException e) {
            // If icon not found, use emoji fallback
            JLabel iconLabel = new JLabel("👨‍🎓");
             iconLabel.setFont(UIFont.LABEL.deriveFont(24f));
            titlePanel.add(iconLabel);
        }

        JLabel cardTitle = new JLabel("Register New Student");
        cardTitle.setFont(UIFont.GROUP_HEADER);
        cardTitle.setForeground(TEXT_PRIMARY);
        titlePanel.add(cardTitle);

        titlePanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Student ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel idLabel = new JLabel("Student ID:");
        idLabel.setFont(UIFont.LABEL);
        idLabel.setForeground(TEXT_PRIMARY);
        panel.add(idLabel, gbc);
        gbc.gridx = 1;
        idField = new JTextField(15);
        idField.setEditable(false);
        // semi-transparent field background so student-management background is visible
        idField.setBackground(new Color(255, 255, 255, 200));
        idField.setOpaque(true);
        idField.setFont(UIFont.INPUT);
        idField.setText(generateStudentId());
        panel.add(idField, gbc);

        // First Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setFont(UIFont.LABEL);
        firstNameLabel.setForeground(TEXT_PRIMARY);
        panel.add(firstNameLabel, gbc);
        gbc.gridx = 1;
        firstNameField = new JTextField(15);
        firstNameField.setFont(UIFont.INPUT);
        firstNameField.setBackground(new Color(255, 255, 255, 200));
        firstNameField.setOpaque(true);
        panel.add(firstNameField, gbc);

        // Surname
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel surnameLabel = new JLabel("Surname:");
        surnameLabel.setFont(UIFont.LABEL);
        surnameLabel.setForeground(TEXT_PRIMARY);
        panel.add(surnameLabel, gbc);
        gbc.gridx = 1;
        surnameField = new JTextField(15);
        surnameField.setFont(UIFont.INPUT);
        surnameField.setBackground(new Color(255, 255, 255, 200));
        surnameField.setOpaque(true);
        panel.add(surnameField, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setFont(UIFont.LABEL);
        emailLabel.setForeground(TEXT_PRIMARY);
        panel.add(emailLabel, gbc);
        gbc.gridx = 1;
        emailField = new JTextField(15);
        emailField.setFont(UIFont.INPUT);
        emailField.setBackground(new Color(255, 255, 255, 200));
        emailField.setOpaque(true);
        panel.add(emailField, gbc);

        // Date of Birth
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel dobLabel = new JLabel("Date of Birth:");
        dobLabel.setFont(UIFont.LABEL);
        dobLabel.setForeground(TEXT_PRIMARY);
        panel.add(dobLabel, gbc);
        gbc.gridx = 1;
        JPanel dobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        dobPanel.setOpaque(false);
        dobField = new JTextField(12);
        dobField.setEditable(false);
        dobField.setFont(UIFont.INPUT);
        dobField.setBackground(new Color(255, 255, 255, 200));
        dobField.setOpaque(true);
        dobField.setToolTipText("Click the calendar button to select date");
        JButton calendarButton = new JButton("...");
        calendarButton.setFont(UIFont.BUTTON.deriveFont(12f));
        calendarButton.setToolTipText("Select Date");
        calendarButton.setFocusPainted(false);
        calendarButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        calendarButton.addActionListener(e -> {
            String selectedDate = selectDateFromCalendar();
            if (selectedDate != null) {
                dobField.setText(selectedDate);
            }
        });
        dobPanel.add(dobField);
        dobPanel.add(calendarButton);
        panel.add(dobPanel, gbc);

        // Programme
        gbc.gridx = 0;
        gbc.gridy = 5;
        JLabel programmeLabel = new JLabel("Programme:");
        programmeLabel.setFont(UIFont.LABEL);
        programmeLabel.setForeground(TEXT_PRIMARY);
        panel.add(programmeLabel, gbc);
        gbc.gridx = 1;
        String[] programmes = {
            "Computer Science",
            "Software Engineering",
            "Data Science & Analytics",
            "Artificial Intelligence / Machine Learning",
            "Cybersecurity",
            "Information Systems",
            "Mathematics",
            "Statistics",
            "Physics",
            "Chemistry",
            "Biology / Life Sciences",
            "Electrical & Electronic Engineering",
            "Mechanical Engineering",
            "Civil & Environmental Engineering",
            "Chemical Engineering",
            "Accounting",
            "Finance",
            "Marketing",
            "Management & HR",
            "Business",
            "Psychology",
            "Sociology",
            "Political Science / International Relations",
            "Economics",
            "English & Literature",
            "History",
            "Philosophy",
            "Law",
            "Nursing",
            "Education"
        };
        programmeComboBox = new JComboBox<>(programmes);
        programmeComboBox.setFont(UIFont.INPUT);
        // combo background slightly translucent
        programmeComboBox.setOpaque(true);
        programmeComboBox.setBackground(new Color(255,255,255,200));
        panel.add(programmeComboBox, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttonPanel.setOpaque(false);

        JButton registerButton = new JButton("✓ Register Student");
        registerButton.setFont(UIFont.BUTTON.deriveFont(Font.BOLD, 13f));
        registerButton.setForeground(Color.WHITE);
        registerButton.setBackground(ACCENT_COLOR);
        registerButton.setFocusPainted(false);
        registerButton.setBorderPainted(false);
        registerButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        registerButton.setPreferredSize(new Dimension(140, 36));
        registerButton.addActionListener(e -> registerStudent());

        // Hover effect for register button
        registerButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                registerButton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                registerButton.setBackground(ACCENT_COLOR);
            }
        });

        JButton clearButton = new JButton("✕ Clear");
        clearButton.setFont(UIFont.BUTTON);
        clearButton.setForeground(TEXT_PRIMARY);
        clearButton.setBackground(new Color(236, 240, 241));
        clearButton.setFocusPainted(false);
        clearButton.setBorderPainted(false);
        clearButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        clearButton.setPreferredSize(new Dimension(100, 36));
        clearButton.addActionListener(e -> clearFields());

        buttonPanel.add(registerButton);
        buttonPanel.add(clearButton);

        panel.add(buttonPanel, gbc);

        // Add title panel and form panel to card
        cardPanel.add(titlePanel, BorderLayout.NORTH);
        cardPanel.add(panel, BorderLayout.CENTER);

        return cardPanel;
    }

    private JPanel createTablePanel() {
         // Card-style panel for table
         JPanel cardPanel = new JPanel(new BorderLayout());
         cardPanel.setOpaque(false);
         cardPanel.setBorder(BorderFactory.createCompoundBorder(
             BorderFactory.createLineBorder(Color.BLACK, 1),
             BorderFactory.createEmptyBorder(16, 16, 16, 16)
         ));

         // Title for the card
         JLabel cardTitle = new JLabel("Registered Students");
         cardTitle.setFont(UIFont.GROUP_HEADER);
         cardTitle.setForeground(TEXT_PRIMARY);
         cardTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

         // Create table with modern styling
         String[] columnNames = {"Student ID", "First Name", "Surname", "Email", "Date of Birth", "Programme"};
         tableModel = new DefaultTableModel(columnNames, 0) {
             @Override
             public boolean isCellEditable(int row, int column) {
                 return false;
             }
         };
         studentTable = new JTable(tableModel);
         // Make table transparent so the student-management background can show through
         studentTable.setOpaque(false);
         studentTable.setBackground(new Color(0,0,0,0));
         studentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         studentTable.setFont(UIFont.TABLE_TEXT);
         studentTable.setRowHeight(28);
         studentTable.setShowVerticalLines(false);
         studentTable.setGridColor(new Color(230, 230, 230));
         studentTable.setSelectionBackground(new Color(52, 152, 219, 50));
         studentTable.setSelectionForeground(TEXT_PRIMARY);

         // Style table header
         JTableHeader header = studentTable.getTableHeader();
         header.setFont(UIFont.TABLE_HEADER);
         header.setBackground(TABLE_HEADER_BG);
         header.setForeground(TEXT_PRIMARY);
         header.setPreferredSize(new Dimension(header.getPreferredSize().width, 35));

         // Add striped row effect
        studentTable.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                    boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    // semi-transparent stripes so the background image shows through
                    Color even = new Color(255, 255, 255, 140); // lighter
                    Color odd = new Color(255, 255, 255, 60);   // subtler
                    c.setBackground(row % 2 == 0 ? even : odd);
                }
                setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(studentTable);
        scrollPane.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
        // Make the viewport non-opaque so the student-management background can show through
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0,0,0,0));

        // Refresh button with icon
        JButton refreshButton = new JButton("Refresh List");
        refreshButton.setFont(UIFont.BUTTON);
        refreshButton.setForeground(TEXT_PRIMARY);
        refreshButton.setBackground(new Color(236, 240, 241));
        refreshButton.setFocusPainted(false);
        refreshButton.setBorderPainted(false);
        refreshButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        refreshButton.setPreferredSize(new Dimension(130, 36));
        refreshButton.addActionListener(e -> refreshTable());

        // Hover effect for refresh button
        refreshButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                refreshButton.setBackground(ACCENT_COLOR);
                refreshButton.setForeground(Color.WHITE);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                refreshButton.setBackground(new Color(236, 240, 241));
                refreshButton.setForeground(TEXT_PRIMARY);
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(8, 0, 0, 0));
        buttonPanel.add(refreshButton);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setOpaque(false);
        contentPanel.add(scrollPane, BorderLayout.CENTER);
        contentPanel.add(buttonPanel, BorderLayout.SOUTH);

        cardPanel.add(cardTitle, BorderLayout.NORTH);
        cardPanel.add(contentPanel, BorderLayout.CENTER);

        return cardPanel;
    }

    private void registerStudent() {
        try {
            String id = idField.getText().trim();
            String firstName = firstNameField.getText().trim();
            String surname = surnameField.getText().trim();
            String email = emailField.getText().trim();
            String dob = dobField.getText().trim();
            String programme = (String) programmeComboBox.getSelectedItem();

            if (id.isEmpty() || firstName.isEmpty() || surname.isEmpty() || email.isEmpty() || dob.isEmpty() || programme == null) {
                JOptionPane.showMessageDialog(this,
                        "All fields are required!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            Student student = service.registerStudent(id, firstName, surname, email, dob, programme);

            // Add to table
            tableModel.addRow(new Object[]{
                    student.getId(),
                    student.getFirstName(),
                    student.getSurname(),
                    student.getEmail(),
                    student.getDateOfBirth(),
                    student.getProgramme()
            });

            JOptionPane.showMessageDialog(this,
                    "Student registered successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            clearFields();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Registration Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText(generateStudentId());
        firstNameField.setText("");
        surnameField.setText("");
        emailField.setText("");
        dobField.setText("");
        programmeComboBox.setSelectedIndex(0);
        firstNameField.requestFocus();
    }

    private String generateStudentId() {
        // Get the next sequential student ID from the database
        try {
            return service.getNextStudentId();
        } catch (Exception e) {
            // If there's an error, default to SE001001
            return "SE001001";
        }
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        try {
            for (ses.model.Student student : service.getAllStudents()) {
                tableModel.addRow(new Object[]{
                        student.getId(),
                        student.getFirstName(),
                        student.getSurname(),
                        student.getEmail(),
                        student.getDateOfBirth(),
                        student.getProgramme()
                });
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error refreshing table: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private JPanel createProfileManagementPanel() {
        JPanel panel = new JPanel(new BorderLayout(15, 15));
        panel.setOpaque(false);

        // Search Panel (card style)
        JPanel searchCard = new JPanel(new FlowLayout(FlowLayout.LEFT, 12, 12));
        searchCard.setOpaque(false);
        searchCard.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 1),
            BorderFactory.createEmptyBorder(12, 16, 12, 16)
        ));

        JLabel searchLabel = new JLabel("Student ID:");
        searchLabel.setFont(UIFont.LABEL);
        searchLabel.setForeground(TEXT_PRIMARY);
        searchCard.add(searchLabel);

        searchIdField = new JTextField(20);
        searchIdField.setFont(UIFont.INPUT);
        searchIdField.setBackground(new Color(255,255,255,200));
        searchIdField.setOpaque(true);
        searchCard.add(searchIdField);

        JButton searchButton = new JButton("Search");
        searchButton.setFont(new Font(UIFont.BUTTON.getFamily(), Font.BOLD, 13));
        searchButton.setForeground(Color.WHITE);
        searchButton.setBackground(ACCENT_COLOR);
        searchButton.setFocusPainted(false);
        searchButton.setBorderPainted(false);
        searchButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        searchButton.setPreferredSize(new Dimension(110, 32));
        searchButton.addActionListener(e -> searchStudent());

        // Hover effect
        searchButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                searchButton.setBackground(new Color(41, 128, 185));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                searchButton.setBackground(ACCENT_COLOR);
            }
        });

        searchCard.add(searchButton);
        panel.add(searchCard, BorderLayout.NORTH);

        // Center panel with view and edit sections
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 15, 15));
        centerPanel.setOpaque(false);

        // View Profile Panel
        JPanel viewPanel = createViewProfilePanel();
        centerPanel.add(viewPanel);

        // Edit Profile Panel
        JPanel editPanel = createEditProfilePanel();
        centerPanel.add(editPanel);

        panel.add(centerPanel, BorderLayout.CENTER);

        return panel;
    }

    private JPanel createViewProfilePanel() {
        // Card-style panel
        JPanel cardPanel = new JPanel(new BorderLayout());
        cardPanel.setOpaque(false);
        cardPanel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 1),
            BorderFactory.createEmptyBorder(16, 16, 16, 16)
        ));

        // Title
        JLabel cardTitle = new JLabel("Student Profile");
        cardTitle.setFont(UIFont.GROUP_HEADER);
        cardTitle.setForeground(TEXT_PRIMARY);
        cardTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Student ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel idLabelText = new JLabel("Student ID:");
        idLabelText.setFont(UIFont.LABEL);
        idLabelText.setForeground(TEXT_SECONDARY);
        panel.add(idLabelText, gbc);
        gbc.gridx = 1;
        profileIdLabel = new JLabel("-");
        profileIdLabel.setFont(UIFont.INPUT);
        profileIdLabel.setForeground(TEXT_PRIMARY);
        panel.add(profileIdLabel, gbc);

        // First Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel firstNameLabelText = new JLabel("First Name:");
        firstNameLabelText.setFont(UIFont.LABEL);
        firstNameLabelText.setForeground(TEXT_SECONDARY);
        panel.add(firstNameLabelText, gbc);
        gbc.gridx = 1;
        profileFirstNameLabel = new JLabel("-");
        profileFirstNameLabel.setFont(UIFont.INPUT);
        profileFirstNameLabel.setForeground(TEXT_PRIMARY);
        panel.add(profileFirstNameLabel, gbc);

        // Surname
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel surnameLabelText = new JLabel("Surname:");
        surnameLabelText.setFont(UIFont.LABEL);
        surnameLabelText.setForeground(TEXT_SECONDARY);
        panel.add(surnameLabelText, gbc);
        gbc.gridx = 1;
        profileSurnameLabel = new JLabel("-");
        profileSurnameLabel.setFont(UIFont.INPUT);
        profileSurnameLabel.setForeground(TEXT_PRIMARY);
        panel.add(profileSurnameLabel, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel emailLabelText = new JLabel("Email:");
        emailLabelText.setFont(UIFont.LABEL);
        emailLabelText.setForeground(TEXT_SECONDARY);
        panel.add(emailLabelText, gbc);
        gbc.gridx = 1;
        profileEmailLabel = new JLabel("-");
        profileEmailLabel.setFont(UIFont.INPUT);
        profileEmailLabel.setForeground(TEXT_PRIMARY);
        panel.add(profileEmailLabel, gbc);

        // Date of Birth
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel dobLabelText = new JLabel("Date of Birth:");
        dobLabelText.setFont(UIFont.LABEL);
        dobLabelText.setForeground(TEXT_SECONDARY);
        panel.add(dobLabelText, gbc);
        gbc.gridx = 1;
        profileDobLabel = new JLabel("-");
        profileDobLabel.setFont(UIFont.INPUT);
        profileDobLabel.setForeground(TEXT_PRIMARY);
        panel.add(profileDobLabel, gbc);

        // Programme
        gbc.gridx = 0;
        gbc.gridy = 5;
        JLabel programmeLabelText = new JLabel("Programme:");
        programmeLabelText.setFont(UIFont.LABEL);
        programmeLabelText.setForeground(TEXT_SECONDARY);
        panel.add(programmeLabelText, gbc);
        gbc.gridx = 1;
        profileProgrammeLabel = new JLabel("-");
        profileProgrammeLabel.setFont(UIFont.INPUT);
        profileProgrammeLabel.setForeground(TEXT_PRIMARY);
        panel.add(profileProgrammeLabel, gbc);

        cardPanel.add(cardTitle, BorderLayout.NORTH);
        cardPanel.add(panel, BorderLayout.CENTER);

        return cardPanel;
    }

    private JPanel createEditProfilePanel() {
         // Card-style panel
         JPanel cardPanel = new JPanel(new BorderLayout());
         cardPanel.setOpaque(false);
         cardPanel.setBorder(BorderFactory.createCompoundBorder(
             BorderFactory.createLineBorder(Color.BLACK, 1),
             BorderFactory.createEmptyBorder(16, 16, 16, 16)
         ));

         // Title
         JLabel cardTitle = new JLabel("Edit Student Information");
         cardTitle.setFont(UIFont.GROUP_HEADER);
         cardTitle.setForeground(TEXT_PRIMARY);
         cardTitle.setBorder(BorderFactory.createEmptyBorder(0, 0, 12, 0));

         JPanel panel = new JPanel(new GridBagLayout());
         panel.setOpaque(false);
         GridBagConstraints gbc = new GridBagConstraints();
         gbc.insets = new Insets(8, 8, 8, 8);
         gbc.fill = GridBagConstraints.HORIZONTAL;

        // First Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel editFirstNameLabel = new JLabel("First Name:");
        editFirstNameLabel.setFont(UIFont.LABEL);
        editFirstNameLabel.setForeground(TEXT_PRIMARY);
        panel.add(editFirstNameLabel, gbc);
        gbc.gridx = 1;
        editFirstNameField = new JTextField(15);
        editFirstNameField.setFont(UIFont.INPUT);
        editFirstNameField.setBackground(new Color(255,255,255,200));
        editFirstNameField.setOpaque(true);
        panel.add(editFirstNameField, gbc);

        // Surname
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel editSurnameLabel = new JLabel("Surname:");
        editSurnameLabel.setFont(UIFont.LABEL);
        editSurnameLabel.setForeground(TEXT_PRIMARY);
        panel.add(editSurnameLabel, gbc);
        gbc.gridx = 1;
        editSurnameField = new JTextField(15);
        editSurnameField.setFont(UIFont.INPUT);
        editSurnameField.setBackground(new Color(255,255,255,200));
        editSurnameField.setOpaque(true);
        panel.add(editSurnameField, gbc);

        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel editEmailLabel = new JLabel("Email:");
        editEmailLabel.setFont(UIFont.LABEL);
        editEmailLabel.setForeground(TEXT_PRIMARY);
        panel.add(editEmailLabel, gbc);
        gbc.gridx = 1;
        editEmailField = new JTextField(15);
        editEmailField.setFont(UIFont.INPUT);
        editEmailField.setBackground(new Color(255,255,255,200));
        editEmailField.setOpaque(true);
        panel.add(editEmailField, gbc);

        // Date of Birth with calendar
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel editDobLabel = new JLabel("Date of Birth:");
        editDobLabel.setFont(UIFont.LABEL);
        editDobLabel.setForeground(TEXT_PRIMARY);
        panel.add(editDobLabel, gbc);
        gbc.gridx = 1;
        JPanel editDobPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        editDobPanel.setOpaque(false);
        editDobField = new JTextField(12);
        editDobField.setEditable(false);
        editDobField.setFont(UIFont.INPUT);
        editDobField.setBackground(new Color(255,255,255,200));
        editDobField.setOpaque(true);
         JButton editCalendarButton = new JButton("...");
        editCalendarButton.setFont(UIFont.BUTTON.deriveFont(12f));
        editCalendarButton.setToolTipText("Select Date");
        editCalendarButton.setFocusPainted(false);
        editCalendarButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        editCalendarButton.addActionListener(e -> {
            String selectedDate = selectDateFromCalendar();
            if (selectedDate != null) {
                editDobField.setText(selectedDate);
            }
        });
        editDobPanel.add(editDobField);
        editDobPanel.add(editCalendarButton);
        panel.add(editDobPanel, gbc);

        // Programme
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel editProgrammeLabel = new JLabel("Programme:");
        editProgrammeLabel.setFont(UIFont.LABEL);
        editProgrammeLabel.setForeground(TEXT_PRIMARY);
        panel.add(editProgrammeLabel, gbc);
        gbc.gridx = 1;
        String[] programmes = {
            "Computer Science",
            "Software Engineering",
            "Data Science & Analytics",
            "Artificial Intelligence / Machine Learning",
            "Cybersecurity",
            "Information Systems",
            "Mathematics",
            "Statistics",
            "Physics",
            "Chemistry",
            "Biology / Life Sciences",
            "Electrical & Electronic Engineering",
            "Mechanical Engineering",
            "Civil & Environmental Engineering",
            "Chemical Engineering",
            "Accounting",
            "Finance",
            "Marketing",
            "Management & HR",
            "Business",
            "Psychology",
            "Sociology",
            "Political Science / International Relations",
            "Economics",
            "English & Literature",
            "History",
            "Philosophy",
            "Law",
            "Nursing",
            "Education"
        };
        editProgrammeComboBox = new JComboBox<>(programmes);
        editProgrammeComboBox.setFont(UIFont.INPUT);
        panel.add(editProgrammeComboBox, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 0));
        buttonPanel.setOpaque(false);

        JButton updateButton = new JButton("Update Profile");
        updateButton.setFont(new Font(UIFont.BUTTON.getFamily(), Font.BOLD, 13));
        updateButton.setForeground(Color.WHITE);
        updateButton.setBackground(new Color(46, 204, 113)); // Green
        updateButton.setFocusPainted(false);
        updateButton.setBorderPainted(false);
        updateButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        updateButton.setPreferredSize(new Dimension(150, 36));
        updateButton.addActionListener(e -> updateStudentProfile());

        // Hover effect
        updateButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                updateButton.setBackground(new Color(39, 174, 96));
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                updateButton.setBackground(new Color(46, 204, 113));
            }
        });

        JButton clearButton = new JButton("✕ Clear");
        clearButton.setFont(UIFont.BUTTON);
        clearButton.setForeground(TEXT_PRIMARY);
        clearButton.setBackground(new Color(236, 240, 241));
        clearButton.setFocusPainted(false);
        clearButton.setBorderPainted(false);
        clearButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
        clearButton.setPreferredSize(new Dimension(100, 36));
        clearButton.addActionListener(e -> clearEditFields());

        buttonPanel.add(updateButton);
        buttonPanel.add(clearButton);

        panel.add(buttonPanel, gbc);

        cardPanel.add(cardTitle, BorderLayout.NORTH);
        cardPanel.add(panel, BorderLayout.CENTER);

        return cardPanel;
    }

    private void searchStudent() {
        String studentId = searchIdField.getText().trim();
        if (studentId.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "Please enter a Student ID",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            Student student = service.getStudentById(studentId);
            if (student != null) {
                // Update view labels
                profileIdLabel.setText(student.getId());
                profileFirstNameLabel.setText(student.getFirstName());
                profileSurnameLabel.setText(student.getSurname());
                profileEmailLabel.setText(student.getEmail());
                profileDobLabel.setText(student.getDateOfBirth());
                profileProgrammeLabel.setText(student.getProgramme());

                // Update edit fields
                editFirstNameField.setText(student.getFirstName());
                editSurnameField.setText(student.getSurname());
                editEmailField.setText(student.getEmail());
                editDobField.setText(student.getDateOfBirth());
                editProgrammeComboBox.setSelectedItem(student.getProgramme());
            } else {
                JOptionPane.showMessageDialog(this,
                        "Student not found!",
                        "Search Result",
                        JOptionPane.INFORMATION_MESSAGE);
                clearProfileView();
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Search Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void updateStudentProfile() {
        String studentId = profileIdLabel.getText();
        if (studentId.equals("-")) {
            JOptionPane.showMessageDialog(this,
                    "Please search for a student first",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
            return;
        }

        try {
            String firstName = editFirstNameField.getText().trim();
            String surname = editSurnameField.getText().trim();
            String email = editEmailField.getText().trim();
            String dob = editDobField.getText().trim();
            String programme = (String) editProgrammeComboBox.getSelectedItem();

            if (firstName.isEmpty() || surname.isEmpty() || email.isEmpty() || dob.isEmpty() || programme == null) {
                JOptionPane.showMessageDialog(this,
                        "All fields are required!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            service.updateStudent(studentId, firstName, surname, email, dob, programme);

            JOptionPane.showMessageDialog(this,
                    "Student profile updated successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            // Refresh the view
            searchStudent();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Update Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearProfileView() {
        profileIdLabel.setText("-");
        profileFirstNameLabel.setText("-");
        profileSurnameLabel.setText("-");
        profileEmailLabel.setText("-");
        profileDobLabel.setText("-");
        profileProgrammeLabel.setText("-");
        clearEditFields();
    }

    private void clearEditFields() {
        editFirstNameField.setText("");
        editSurnameField.setText("");
        editEmailField.setText("");
        editDobField.setText("");
        editProgrammeComboBox.setSelectedIndex(0);
    }

    private String selectDateFromCalendar() {
        JDialog dialog = new JDialog((Frame) SwingUtilities.getWindowAncestor(this), "Select Date of Birth", true);
        dialog.setLayout(new BorderLayout(10, 10));

        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create spinners for year, month, and day
        JPanel datePanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));

        // Year spinner (1900 to current year)
        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
        SpinnerNumberModel yearModel = new SpinnerNumberModel(2000, 1900, currentYear, 1);
        JSpinner yearSpinner = new JSpinner(yearModel);
        JSpinner.NumberEditor yearEditor = new JSpinner.NumberEditor(yearSpinner, "0000");
        yearSpinner.setEditor(yearEditor);

        // Month spinner (1-12)
        SpinnerNumberModel monthModel = new SpinnerNumberModel(1, 1, 12, 1);
        JSpinner monthSpinner = new JSpinner(monthModel);
        JSpinner.NumberEditor monthEditor = new JSpinner.NumberEditor(monthSpinner, "00");
        monthSpinner.setEditor(monthEditor);

        // Day spinner (1-31)
        SpinnerNumberModel dayModel = new SpinnerNumberModel(1, 1, 31, 1);
        JSpinner daySpinner = new JSpinner(dayModel);
        JSpinner.NumberEditor dayEditor = new JSpinner.NumberEditor(daySpinner, "00");
        daySpinner.setEditor(dayEditor);

        datePanel.add(new JLabel("Year:"));
        datePanel.add(yearSpinner);
        datePanel.add(new JLabel("Month:"));
        datePanel.add(monthSpinner);
        datePanel.add(new JLabel("Day:"));
        datePanel.add(daySpinner);

        panel.add(datePanel, BorderLayout.CENTER);

        // OK and Cancel buttons
        final String[] selectedDate = {null};
        JButton okButton = new JButton("OK");
        okButton.addActionListener(e -> {
            int year = (Integer) yearSpinner.getValue();
            int month = (Integer) monthSpinner.getValue();
            int day = (Integer) daySpinner.getValue();
            selectedDate[0] = String.format("%04d-%02d-%02d", year, month, day);
            dialog.dispose();
        });

        JButton cancelButton = new JButton("Cancel");
        cancelButton.addActionListener(e -> dialog.dispose());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        buttonPanel.add(okButton);
        buttonPanel.add(cancelButton);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        dialog.add(panel);
        dialog.pack();
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);

        return selectedDate[0];
    }
}
