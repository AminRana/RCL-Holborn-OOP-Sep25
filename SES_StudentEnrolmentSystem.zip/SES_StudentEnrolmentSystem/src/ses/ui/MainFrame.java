package ses.ui;

import ses.service.EnrollmentService;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {

    private final EnrollmentService service;
    private JPanel contentPanel;
    private CardLayout cardLayout;
    private BackgroundPanel bgPanel;

    public MainFrame(EnrollmentService service) {
        this.service = service;
        initializeUI();
    }

    private void initializeUI() {
        setTitle("Student Enrollment System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1400, 800);
        setLocationRelativeTo(null);

        // Set background image for the frame using BackgroundPanel
        bgPanel = new BackgroundPanel("/icons/bg.png", BackgroundPanel.Mode.SCALE);
        setContentPane(bgPanel);

        // Toggle background visibility with Ctrl+B for quick testing
        getRootPane().getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control B"), "toggleBackground");
        getRootPane().getActionMap().put("toggleBackground", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                bgPanel.setShowBackground(!bgPanel.isShowBackground());
            }
        });

        // Create menu bar (keep for File menu)
        createMenuBar();

        // Create colorful button panel at the top
        add(createButtonPanel(), BorderLayout.NORTH);

        // Create main content area with CardLayout
        cardLayout = new CardLayout();
        contentPanel = new JPanel(cardLayout);
        contentPanel.setOpaque(false); // allow background to show through

        // Add panels
        contentPanel.add(new WelcomePanel(), "welcome");
        contentPanel.add(new StudentPanel(service), "students");
        contentPanel.add(new EnrollmentPanel(service), "enrollments");
        contentPanel.add(new GradePanel(service), "grades");
        contentPanel.add(new CoursesCompletedPanel(service), "coursesCompleted");
        contentPanel.add(new ReportPanel(service), "reports");

        add(contentPanel, BorderLayout.CENTER);

        // Show welcome panel by default
        cardLayout.show(contentPanel, "welcome");
    }

    private JPanel createButtonPanel() {
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(1, 6, 2, 0)); // 1 row, 6 columns (added Home button), 2px horizontal gap for borders
        buttonPanel.setOpaque(false); // Make transparent
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        buttonPanel.setPreferredSize(new Dimension(0, 70)); // Height of 70px, width stretches

        // White color for all buttons
        Color white = Color.WHITE;

        // Create white buttons with icons
        JButton homeBtn = createColorfulButton("Home", white, "welcome");
        JButton studentsBtn = createColorfulButton("Students", white, "students");
        JButton enrollmentsBtn = createColorfulButton("Enrollments", white, "enrollments");
        JButton gradeBtn = createColorfulButton("Grade", white, "grades");
        JButton coursesBtn = createColorfulButton("Courses Completed", white, "coursesCompleted");
        JButton reportsBtn = createColorfulButton("Reports", white, "reports");

        buttonPanel.add(homeBtn);
        buttonPanel.add(studentsBtn);
        buttonPanel.add(enrollmentsBtn);
        buttonPanel.add(gradeBtn);
        buttonPanel.add(coursesBtn);
        buttonPanel.add(reportsBtn);

        return buttonPanel;
    }

    private JButton createColorfulButton(String text, Color bgColor, String panelName) {
        JButton button = new JButton(text);
        button.setFont(new Font(UIFont.BUTTON.getFamily(), Font.BOLD, 18));
        button.setForeground(Color.BLACK);
        button.setBackground(bgColor);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));

        // Add hover effect
        button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                button.setBackground(new Color(27, 230, 37)); // Light gray on hover
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                button.setBackground(bgColor);
            }
        });

        // Add click action
        button.addActionListener(e -> cardLayout.show(contentPanel, panelName));

        return button;
    }

    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(69, 55, 112)); // Steel Blue
        menuBar.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

        // File Menu
        JMenu fileMenu = createStyledMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        menuBar.add(fileMenu);

        // About Menu
        JMenu aboutMenu = createStyledMenu("About");
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(e -> showAboutDialog());
        aboutMenu.add(aboutItem);

        menuBar.add(aboutMenu);

        setJMenuBar(menuBar);
    }

    private void showAboutDialog() {
        String message = "Student Enrollment System\n\n" +
                "Created by: Oluwadamiler Onabanjo\n\n" +
                "This project was developed as part of the\n" +
                "Object Oriented Programming (Java) course\n" +
                "at Regent College London\n" +
                "(University of Greater Manchester)\n\n" +
                "© 2025 All Rights Reserved";

        JOptionPane.showMessageDialog(
                this,
                message,
                "About Student Enrollment System",
                JOptionPane.INFORMATION_MESSAGE
        );
    }

    private JMenu createStyledMenu(String title) {
        JMenu menu = new JMenu(title);
        menu.setForeground(Color.BLACK);
        // Use the chosen UI family, slightly smaller than group header
        menu.setFont(new Font(UIFont.GROUP_HEADER.getFamily(), Font.BOLD, 14));
        return menu;
    }

    // Welcome Panel
    private static class WelcomePanel extends JPanel {
        public WelcomePanel() {
            setLayout(new BorderLayout());
            setOpaque(false); // allow background image to show through

            // Create center panel (transparent)
            JPanel centerPanel = new JPanel();
            centerPanel.setOpaque(false);
            centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
            centerPanel.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

            // Welcome title - Bold, bigger, wider
            JLabel welcomeLabel = new JLabel("Student Enrollment System", SwingConstants.CENTER);
            welcomeLabel.setFont(new Font(UIFont.APP_TITLE.getFamily(), Font.BOLD, 48));
            welcomeLabel.setForeground(Color.WHITE);
            welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Subtitle - Bold, bigger, wider
            JLabel subtitleLabel = new JLabel("Manage Students, Courses & Enrollments", SwingConstants.CENTER);
            subtitleLabel.setFont(new Font(UIFont.GROUP_HEADER.getFamily(), Font.BOLD, 32));
            subtitleLabel.setForeground(Color.WHITE);
            subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Instruction - Bold, bigger, wider
            JLabel instructionLabel = new JLabel("Use the buttons above to navigate", SwingConstants.CENTER);
            instructionLabel.setFont(new Font(UIFont.LABEL.getFamily(), Font.BOLD, 24));
            instructionLabel.setForeground(Color.WHITE);
            instructionLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            // Add spacing
            centerPanel.add(Box.createVerticalGlue());
            centerPanel.add(welcomeLabel);
            centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
            centerPanel.add(subtitleLabel);
            centerPanel.add(Box.createRigidArea(new Dimension(0, 30)));
            centerPanel.add(instructionLabel);
            centerPanel.add(Box.createVerticalGlue());

            add(centerPanel, BorderLayout.CENTER);

            // Footer
            JLabel footerLabel = new JLabel("© 2025 Student Enrollment System", SwingConstants.CENTER);
            footerLabel.setFont(UIFont.LABEL.deriveFont(12f));
            footerLabel.setForeground(new Color(100, 100, 100));
            footerLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            add(footerLabel, BorderLayout.SOUTH);
        }
    }
}
