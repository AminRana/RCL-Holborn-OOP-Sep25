package ses.ui;

import ses.model.Course;
import ses.service.EnrollmentService;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class GradePanel extends JPanel {

    private final EnrollmentService service;
    private JTextField studentIdField, scoreField;
    private JComboBox<String> courseComboBox;
    private JComboBox<String> semesterComboBox;
    private JComboBox<String> yearComboBox;
    private BackgroundPanel gradeBg;

    public GradePanel(EnrollmentService service) {
        this.service = service;
        initializeUI();
        loadCourses();
    }

    private void initializeUI() {
        // Wrap grade area in BackgroundPanel so it has its own background image
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        gradeBg = new BackgroundPanel("/icons/grade_management_bg.png", BackgroundPanel.Mode.SCALE);
        gradeBg.setLayout(new BorderLayout(10, 10));
        gradeBg.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel titleLabel = new JLabel("Record Grade", SwingConstants.CENTER);
        titleLabel.setFont(UIFont.APP_TITLE);
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        titleLabel.setOpaque(false);
        gradeBg.add(titleLabel, BorderLayout.NORTH);

        // Input Panel (transparent so background shows through)
        JPanel inputPanel = createInputPanel();
        inputPanel.setOpaque(false);
        gradeBg.add(inputPanel, BorderLayout.CENTER);

        add(gradeBg, BorderLayout.CENTER);

        // Debug: report if external image was loaded and allow quick toggle with Ctrl+G
        System.out.println("GradePanel: external image loaded? " + gradeBg.isExternalImageLoaded());
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control G"), "toggleGradeBg");
        getActionMap().put("toggleGradeBg", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                gradeBg.setShowBackground(!gradeBg.isShowBackground());
                System.out.println("GradePanel: showBackground=" + gradeBg.isShowBackground());
            }
        });
    }

    private JPanel createInputPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.BLACK, 2),
            BorderFactory.createTitledBorder(
                BorderFactory.createEmptyBorder(10, 10, 10, 10),
                "Enter Grade Information",
                0,
                0,
                UIFont.GROUP_HEADER,
                Color.BLACK
            )
        ));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Student ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        JLabel sid = new JLabel("Student ID:");
        sid.setFont(UIFont.LABEL);
        panel.add(sid, gbc);
        gbc.gridx = 1;
        studentIdField = new JTextField(20);
        studentIdField.setFont(UIFont.INPUT);
        studentIdField.setBackground(new Color(255,255,255,200));
        studentIdField.setOpaque(true);
        panel.add(studentIdField, gbc);

        // Course Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        JLabel courseLabel = new JLabel("Course Name:");
        courseLabel.setFont(UIFont.LABEL);
        panel.add(courseLabel, gbc);
        gbc.gridx = 1;
        courseComboBox = new JComboBox<>();
        courseComboBox.setFont(UIFont.INPUT);
        courseComboBox.setOpaque(true);
        courseComboBox.setBackground(new Color(255,255,255,200));
        courseComboBox.setPreferredSize(new Dimension(300, 25));
        panel.add(courseComboBox, gbc);

        // Semester
        gbc.gridx = 0;
        gbc.gridy = 2;
        JLabel semLabel = new JLabel("Semester:");
        semLabel.setFont(UIFont.LABEL);
        panel.add(semLabel, gbc);
        gbc.gridx = 1;
        semesterComboBox = new JComboBox<>(new String[]{"1", "2"});
        semesterComboBox.setFont(UIFont.INPUT);
        semesterComboBox.setOpaque(true);
        semesterComboBox.setBackground(new Color(255,255,255,200));
        semesterComboBox.setPreferredSize(new Dimension(300, 25));
        panel.add(semesterComboBox, gbc);

        // Year
        gbc.gridx = 0;
        gbc.gridy = 3;
        JLabel yearLabel = new JLabel("Year:");
        yearLabel.setFont(UIFont.LABEL);
        panel.add(yearLabel, gbc);
        gbc.gridx = 1;
        yearComboBox = new JComboBox<>();
        yearComboBox.setFont(UIFont.INPUT);
        yearComboBox.setOpaque(true);
        yearComboBox.setBackground(new Color(255,255,255,200));
        for (int year = 2020; year <= 2030; year++) {
            yearComboBox.addItem(String.valueOf(year));
        }
        yearComboBox.setSelectedItem("2025");
        yearComboBox.setPreferredSize(new Dimension(300, 25));
        panel.add(yearComboBox, gbc);

        // Score
        gbc.gridx = 0;
        gbc.gridy = 4;
        JLabel scoreLabel = new JLabel("Score (0-100):");
        scoreLabel.setFont(UIFont.LABEL);
        panel.add(scoreLabel, gbc);
        gbc.gridx = 1;
        scoreField = new JTextField(20);
        scoreField.setFont(UIFont.INPUT);
        scoreField.setBackground(new Color(255,255,255,200));
        scoreField.setOpaque(true);
        panel.add(scoreField, gbc);

        // Buttons
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.setOpaque(false);

        JButton recordButton = new JButton("Record Grade");
        recordButton.setFont(UIFont.BUTTON);
        recordButton.addActionListener(e -> recordGrade());
        buttonPanel.add(recordButton);

        JButton clearButton = new JButton("Clear");
        clearButton.setFont(UIFont.BUTTON);
        clearButton.addActionListener(e -> clearFields());
        buttonPanel.add(clearButton);

        panel.add(buttonPanel, gbc);

        return panel;
    }

    private void recordGrade() {
        try {
            String studentId = studentIdField.getText().trim();
            String selectedCourse = (String) courseComboBox.getSelectedItem();
            String semesterNum = (String) semesterComboBox.getSelectedItem();
            String year = (String) yearComboBox.getSelectedItem();
            String scoreText = scoreField.getText().trim();

            if (studentId.isEmpty() || selectedCourse == null || semesterNum == null || year == null || scoreText.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "All fields are required!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Extract course code from the selected item (format: "CODE - Title")
            String courseCode = selectedCourse.split(" - ")[0];

            // Build semester string in format: YYYY-S#
            String semester = year + "-S" + semesterNum;

            double score = Double.parseDouble(scoreText);

            service.recordGrade(studentId, courseCode, semester, score);

            JOptionPane.showMessageDialog(this,
                    "Grade recorded successfully!",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

            clearFields();

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Score must be a valid number!",
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Grade Recording Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        studentIdField.setText("");
        courseComboBox.setSelectedIndex(0);
        semesterComboBox.setSelectedIndex(0);
        yearComboBox.setSelectedItem("2025");
        scoreField.setText("");
        studentIdField.requestFocus();
    }

    private void loadCourses() {
        try {
            courseComboBox.removeAllItems();
            courseComboBox.addItem("-- Select Course --");

            List<Course> courses = service.getAllCourses();
            for (Course course : courses) {
                courseComboBox.addItem(course.getCode() + " - " + course.getTitle());
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error loading courses: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}
