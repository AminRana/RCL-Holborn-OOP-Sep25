package ses.ui;

import ses.model.Enrollment;
import ses.service.EnrollmentService;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;
import java.util.stream.Collectors;

public class CoursesCompletedPanel extends JPanel {

    private final EnrollmentService service;
    private JTextField studentIdField;
    private DefaultTableModel tableModel;
    private BackgroundPanel coursesBg;

    public CoursesCompletedPanel(EnrollmentService service) {
        this.service = service;
        initializeUI();
    }

    private void initializeUI() {
        // Wrap the Courses Completed UI in a BackgroundPanel so it can have its own background
        setLayout(new BorderLayout());
        setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));

        coursesBg = new BackgroundPanel("/icons/courses_completed_bg.png", BackgroundPanel.Mode.SCALE);
        coursesBg.setLayout(new BorderLayout(10, 10));
        coursesBg.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Title
        JLabel titleLabel = new JLabel("Check Courses Completed", SwingConstants.CENTER);
        titleLabel.setFont(UIFont.APP_TITLE);
        titleLabel.setOpaque(false);
        coursesBg.add(titleLabel, BorderLayout.NORTH);

        // Search panel (transparent so background shows through)
        JPanel searchPanel = createSearchPanel();
        searchPanel.setOpaque(false);
        coursesBg.add(searchPanel, BorderLayout.NORTH);

        // Table Panel
        JPanel tablePanel = createTablePanel();
        tablePanel.setOpaque(false);
        coursesBg.add(tablePanel, BorderLayout.CENTER);

        add(coursesBg, BorderLayout.CENTER);

        // Debug: report if external image loaded and allow Ctrl+K to toggle this panel background
        System.out.println("CoursesCompletedPanel: external image loaded? " + coursesBg.isExternalImageLoaded());
        getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW).put(KeyStroke.getKeyStroke("control K"), "toggleCoursesBg");
        getActionMap().put("toggleCoursesBg", new AbstractAction() {
            @Override
            public void actionPerformed(java.awt.event.ActionEvent e) {
                coursesBg.setShowBackground(!coursesBg.isShowBackground());
                System.out.println("CoursesCompletedPanel: showBackground=" + coursesBg.isShowBackground());
            }
        });
    }

    private JPanel createSearchPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        panel.setBorder(BorderFactory.createTitledBorder("Search Student"));
        panel.setOpaque(false);

        panel.add(new JLabel("Student ID:"));
        studentIdField = new JTextField(20);
        studentIdField.setFont(UIFont.INPUT);
        studentIdField.setBackground(new Color(255, 255, 255, 255));
        studentIdField.setOpaque(true);
        panel.add(studentIdField);

        JButton searchButton = new JButton("Check Completed Courses");
        searchButton.setFont(UIFont.BUTTON);
        searchButton.addActionListener(e -> checkCompletedCourses());
        panel.add(searchButton);

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> clearTable());
        panel.add(clearButton);

        return panel;
    }

    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createTitledBorder("Completed Courses"));
        panel.setOpaque(false);

        // Create table
        String[] columnNames = {"Course Code", "Semester", "Grade", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        JTable coursesTable = new JTable(tableModel);
        coursesTable.setFont(UIFont.TABLE_TEXT);
        // Make table transparent so background shows through
        coursesTable.setOpaque(false);
        coursesTable.setBackground(new Color(0,0,0,0));
        coursesTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Semi-transparent row backgrounds with white text
        coursesTable.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    Color even = new Color(255, 255, 255, 200);
                    Color odd = new Color(240, 240, 240, 200);
                    c.setBackground(row % 2 == 0 ? even : odd);
                    setForeground(Color.BLACK);
                } else {
                    c.setBackground(new Color(100, 150, 200));
                    setForeground(Color.WHITE);
                }
                setBorder(BorderFactory.createEmptyBorder(4,8,4,8));
                return c;
            }
        });

        JScrollPane scrollPane = new JScrollPane(coursesTable);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        scrollPane.getViewport().setBackground(new Color(0,0,0,0));
        panel.add(scrollPane, BorderLayout.CENTER);

        return panel;
    }

    private void checkCompletedCourses() {
        try {
            String studentId = studentIdField.getText().trim();

            if (studentId.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter a Student ID!",
                        "Validation Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            List<Enrollment> enrollments = service.getStudentReport(studentId);

            if (enrollments.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No enrollments found for Student ID: " + studentId,
                        "No Results",
                        JOptionPane.INFORMATION_MESSAGE);
                tableModel.setRowCount(0);
                return;
            }

            // Filter only completed courses (those with grades)
            List<Enrollment> completedCourses = enrollments.stream()
                    .filter(e -> e.getGrade() != null)
                    .collect(Collectors.toList());

            tableModel.setRowCount(0);

            if (completedCourses.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "No completed courses found for this student.",
                        "No Completed Courses",
                        JOptionPane.INFORMATION_MESSAGE);
                return;
            }

            for (Enrollment enrollment : completedCourses) {
                String status = enrollment.getGrade().isPass() ? "PASS" : "FAIL";
                tableModel.addRow(new Object[]{
                        enrollment.getCourse().getCode(),
                        enrollment.getSemester(),
                        enrollment.getGrade().getScore(),
                        status
                });
            }

            JOptionPane.showMessageDialog(this,
                    "Found " + completedCourses.size() + " completed course(s).",
                    "Success",
                    JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this,
                    "Error: " + ex.getMessage(),
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearTable() {
        studentIdField.setText("");
        tableModel.setRowCount(0);
        studentIdField.requestFocus();
    }
}
