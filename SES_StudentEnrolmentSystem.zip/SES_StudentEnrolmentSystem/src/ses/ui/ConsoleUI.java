package ses.ui;

import ses.service.EnrollmentService;

import java.util.Scanner;

public class ConsoleUI {

    private final EnrollmentService service;
    private final Scanner scanner = new Scanner(System.in);

    public ConsoleUI(EnrollmentService service) {
        this.service = service;
    }

    public void start() {
        boolean running = true;

        while (running) {
            printMenu();
            String choice = scanner.nextLine();

            try {
                switch (choice) {
                    case "1" -> registerStudent();
                    case "2" -> addCourse();
                    case "3" -> enrolStudent();
                    case "4" -> recordGrade();
                    case "5" -> viewStudentReport();
                    case "0" -> running = false;
                    default -> System.out.println("Invalid option. Try again.");
                }
            } catch (Exception ex) {
                System.out.println("Error: " + ex.getMessage());
            }
        }

        System.out.println("Exiting Student Enrolment System...");
    }

    private void printMenu() {
        System.out.println("\n=== Student Enrolment System ===");
        System.out.println("1. Register Student");
        System.out.println("2. Add Course");
        System.out.println("3. Enrol Student");
        System.out.println("4. Record Grade");
        System.out.println("5. View Student Report");
        System.out.println("0. Exit");
        System.out.print("Choose an option: ");
    }

    private void registerStudent() {
        System.out.print("Student ID: ");
        String id = scanner.nextLine();
        System.out.print("First Name: ");
        String firstName = scanner.nextLine();
        System.out.print("Surname: ");
        String surname = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Date of Birth (e.g., 2000-01-15): ");
        String dateOfBirth = scanner.nextLine();
        System.out.print("Programme: ");
        String programme = scanner.nextLine();

        service.registerStudent(id, firstName, surname, email, dateOfBirth, programme);
        System.out.println("Student registered successfully.");
    }

    private void addCourse() {
        System.out.print("Course Code: ");
        String code = scanner.nextLine();
        System.out.print("Course Title: ");
        String title = scanner.nextLine();
        System.out.print("Credits: ");
        int credits = Integer.parseInt(scanner.nextLine());

        service.addCourse(code, title, credits);
        System.out.println("Course added successfully.");
    }

    private void enrolStudent() {
        System.out.print("Student ID: ");
        String studentId = scanner.nextLine();
        System.out.print("Course Code: ");
        String courseCode = scanner.nextLine();
        System.out.print("Semester (e.g. 2025-S1): ");
        String semester = scanner.nextLine();

        service.enrolStudent(studentId, courseCode, semester);
        System.out.println("Student enrolled successfully.");
    }

    private void recordGrade() {
        System.out.print("Student ID: ");
        String studentId = scanner.nextLine();
        System.out.print("Course Code: ");
        String courseCode = scanner.nextLine();
        System.out.print("Semester: ");
        String semester = scanner.nextLine();
        System.out.print("Score: ");
        double score = Double.parseDouble(scanner.nextLine());

        service.recordGrade(studentId, courseCode, semester, score);
        System.out.println("Grade recorded successfully.");
    }

    private void viewStudentReport() {
        System.out.print("Student ID: ");
        String studentId = scanner.nextLine();

        System.out.println("\n--- Student Report ---");
        service.getStudentReport(studentId)
                .forEach(System.out::println);
    }
}