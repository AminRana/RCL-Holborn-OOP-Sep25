package ses.ui;

import java.awt.*;
import java.util.HashSet;
import java.util.Set;

/**
 * Centralized UI fonts. Chooses the first available humanist sans from a preferred list
 * (Inter, Roboto, Noto Sans) and falls back to platform defaults (Segoe UI/Helvetica/Arial).
 * Provides commonly used font styles as constants so panels are consistent.
 */
public final class UIFont {
    private static final String[] PREFERRED = {"Inter", "Roboto", "Noto Sans", "Segoe UI", "Helvetica", "Arial"};
    private static final String FAMILY;

    public static final Font APP_TITLE;       // 22 Bold
    public static final Font GROUP_HEADER;    // 17 Bold (semibold)
    public static final Font LABEL;           // 13 Plain
    public static final Font INPUT;           // 13 Plain
    public static final Font BUTTON;          // 14 Plain
    public static final Font TABLE_TEXT;      // 13 Plain
    public static final Font TABLE_HEADER;    // 13 Bold

    static {
        String found = null;
        GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
        Set<String> families = new HashSet<>();
        String[] available = ge.getAvailableFontFamilyNames();
        java.util.Collections.addAll(families, available);

        // Try to load bundled Noto Sans fonts from resources/fonts first and register them
        try {
            java.io.File regular = new java.io.File("resources/fonts/NotoSans-Regular.ttf");
            java.io.File bold = new java.io.File("resources/fonts/NotoSans-Bold.ttf");
            if (regular.exists()) {
                Font fReg = Font.createFont(Font.TRUETYPE_FONT, regular);
                ge.registerFont(fReg);
            }
            if (bold.exists()) {
                Font fBold = Font.createFont(Font.TRUETYPE_FONT, bold);
                ge.registerFont(fBold);
            }
            // refresh available families after registering
            available = ge.getAvailableFontFamilyNames();
            families.clear();
            java.util.Collections.addAll(families, available);
            // prefer the bundled "Noto Sans" family if available
            if (families.contains("Noto Sans")) {
                found = "Noto Sans";
            }
        } catch (Exception ex) {
            // ignore and fallback to system fonts
        }

        for (String p : PREFERRED) {
            if (families.contains(p)) { found = p; break; }
        }
        if (found == null) {
            // last resort choose logical default
            String os = System.getProperty("os.name").toLowerCase();
            if (os.contains("win")) found = "Segoe UI";
            else if (os.contains("mac")) found = "Helvetica";
            else found = "Arial";
        }
        FAMILY = found;

        // Informational logging so you can confirm the chosen font at runtime
        System.out.println("UIFont: chosen font family = " + FAMILY);

        APP_TITLE = new Font(FAMILY, Font.BOLD, 22);
        GROUP_HEADER = new Font(FAMILY, Font.BOLD, 17);
        LABEL = new Font(FAMILY, Font.PLAIN, 13);
        INPUT = new Font(FAMILY, Font.PLAIN, 13);
        BUTTON = new Font(FAMILY, Font.PLAIN, 14);
        TABLE_TEXT = new Font(FAMILY, Font.PLAIN, 13);
        TABLE_HEADER = new Font(FAMILY, Font.BOLD, 13);
    }

    private UIFont() {}
}
