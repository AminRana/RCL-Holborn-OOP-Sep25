package ses.model;

/**
 * Enrollment class represents a student's enrollment in a specific course for a specific semester.
 * Links a Student to a Course with a semester identifier.
 * Can optionally include a Grade once the course is completed and graded.
 */
public class Enrollment {

    // The student enrolled in the course (immutable - cannot change after creation)
    private final Student student;

    // The course the student is enrolled in (immutable)
    private final Course course;

    // The semester identifier (e.g., "2025-S1" for 2025 Semester 1)
    private final String semester;

    // The grade for this enrollment (null until the course is graded)
    // This is the only mutable field - grade can be added/updated after enrollment
    private Grade grade;

    /**
     * Constructor to create a new Enrollment.
     * Creates an enrollment without a grade (grade will be null initially).
     *
     * @param student The student being enrolled (cannot be null)
     * @param course The course being enrolled in (cannot be null)
     * @param semester The semester identifier in format "YYYY-S#" (e.g., "2025-S1")
     * @throws IllegalArgumentException if student is null, course is null, or semester is empty
     */
    public Enrollment(Student student, Course course, String semester) {
        // Validate all required fields are provided
        if (student == null) throw new IllegalArgumentException("Student cannot be null");
        if (course == null) throw new IllegalArgumentException("Course cannot be null");
        if (semester == null || semester.isBlank()) throw new IllegalArgumentException("Semester cannot be empty");

        // Set the immutable fields
        this.student = student;
        this.course = course;
        this.semester = semester;
        // grade is null by default (not yet graded)
    }

    /**
     * Gets the student enrolled in this course.
     *
     * @return The Student object
     */
    public Student getStudent() {
        return student;
    }

    /**
     * Gets the course for this enrollment.
     *
     * @return The Course object
     */
    public Course getCourse() {
        return course;
    }

    /**
     * Gets the semester identifier.
     *
     * @return The semester string (e.g., "2025-S1")
     */
    public String getSemester() {
        return semester;
    }

    /**
     * Gets the grade for this enrollment.
     *
     * @return The Grade object, or null if not yet graded
     */
    public Grade getGrade() {
        return grade;
    }

    /**
     * Sets or updates the grade for this enrollment.
     * Can be called to add a grade after enrollment or to update an existing grade.
     *
     * @param grade The Grade object to assign to this enrollment
     */
    public void setGrade(Grade grade) {
        this.grade = grade;
    }

    /**
     * Checks if this enrollment has been completed (graded).
     *
     * @return true if a grade has been assigned, false if still pending
     */
    public boolean isCompleted() {
        return grade != null;
    }

    /**
     * Returns a detailed string representation of this enrollment.
     * Includes student information, course information, semester, and grade status.
     *
     * @return Multi-line formatted string with all enrollment details
     */
    @Override
    public String toString() {
        // Format grade information - show "N/A" if not graded yet
        String gradeInfo = (grade == null)
                ? "Grade: N/A"
                : "Grade: " + grade.getScore() + (grade.isPass() ? " (PASS)" : " (FAIL)");

        // Build comprehensive enrollment information string
        return "Student: " + student.getId() + " | " + student.getFullName()
                + " | " + student.getEmail()
                + " | Programme: " + student.getProgramme()
                + "\nEnrolled in " + course.getCode() + " - " + course.getTitle()
                + " (" + semester + ") | " + gradeInfo;
    }

    // Main method for testing
    public static void main(String[] args) {
        System.out.println("=== Testing Enrollment Class ===\n");

        // Create test data
        Student student1 = new Student("S001", "Alice", "Johnson", "alice@university.edu", "2000-05-15", "Computer Science");
        Student student2 = new Student("S002", "Bob", "Smith", "bob@university.edu", "2001-08-22", "Software Engineering");
        Course course1 = new Course("SWE4305", "Object-Oriented Programming", 20);
        Course course2 = new Course("MATH101", "Calculus I", 15);

        // Test 1: Create enrollment without grade
        try {
            Enrollment enrollment1 = new Enrollment(student1, course1, "2025-S1");
            System.out.println("✓ Enrollment created successfully:");
            System.out.println(enrollment1);
            System.out.println("  Completed: " + enrollment1.isCompleted());
            System.out.println();
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
        }

        // Test 2: Create enrollment and add grade
        try {
            Enrollment enrollment2 = new Enrollment(student1, course2, "2025-S1");
            System.out.println("✓ Enrollment created:");
            System.out.println(enrollment2);

            Grade grade = new Grade(85.5);
            enrollment2.setGrade(grade);
            System.out.println("\n✓ After adding grade:");
            System.out.println(enrollment2);
            System.out.println("  Completed: " + enrollment2.isCompleted());
            System.out.println();
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
        }

        // Test 3: Create enrollment with failing grade
        try {
            Enrollment enrollment3 = new Enrollment(student2, course1, "2025-S2");
            Grade failingGrade = new Grade(35.0);
            enrollment3.setGrade(failingGrade);
            System.out.println("✓ Enrollment with failing grade:");
            System.out.println(enrollment3);
            System.out.println();
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
        }

        // Test 4: Test getters
        try {
            Enrollment enrollment4 = new Enrollment(student2, course2, "2025-S1");
            System.out.println("✓ Testing getters:");
            System.out.println("  Student: " + enrollment4.getStudent().getFullName());
            System.out.println("  Course: " + enrollment4.getCourse().getCode());
            System.out.println("  Semester: " + enrollment4.getSemester());
            System.out.println("  Grade: " + enrollment4.getGrade());
            System.out.println();
        } catch (Exception e) {
            System.out.println("✗ Error: " + e.getMessage());
        }

        // Test 5: Test validation - null student
        try {
            Enrollment invalidEnrollment = new Enrollment(null, course1, "2025-S1");
            System.out.println("✗ Should have thrown exception for null student");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Validation working: " + e.getMessage());
        }

        // Test 6: Test validation - null course
        try {
            Enrollment invalidEnrollment = new Enrollment(student1, null, "2025-S1");
            System.out.println("✗ Should have thrown exception for null course");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Validation working: " + e.getMessage());
        }

        // Test 7: Test validation - empty semester
        try {
            Enrollment invalidEnrollment = new Enrollment(student1, course1, "");
            System.out.println("✗ Should have thrown exception for empty semester");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Validation working: " + e.getMessage());
        }

        System.out.println("\n=== All Enrollment Tests Complete ===");
    }
}
