package ses.model;

/**
 * Student class represents a student in the enrollment system.
 * Contains all personal information and academic programme details.
 */
public class Student {

    // Student's unique identifier (e.g., "SE001001")
    private final String id;

    // Student's first name
    private String firstName;

    // Student's surname/last name
    private String surname;

    // Student's email address
    private String email;

    // Student's date of birth in format "YYYY-MM-DD"
    private String dateOfBirth;

    // The academic programme the student is enrolled in (e.g., "Computer Science", "Engineering")
    private String programme;

    /**
     * Constructor to create a new Student object.
     *
     * @param id Student ID (e.g., "SE001001") - must be unique
     * @param firstName Student's first name
     * @param surname Student's surname/last name
     * @param email Student's email address
     * @param dateOfBirth Student's date of birth in format "YYYY-MM-DD"
     * @param programme Academic programme the student is enrolled in
     * @throws IllegalArgumentException if any parameter is invalid
     */
    public Student(String id, String firstName, String surname, String email, String dateOfBirth, String programme) {
        // Validate and set ID
        if (id == null || id.isBlank()) {
            throw new IllegalArgumentException("ID cannot be empty");
        }
        this.id = id;

        // Set other fields using setter methods (includes validation)
        setFirstName(firstName);
        setSurname(surname);
        setEmail(email);
        setDateOfBirth(dateOfBirth);
        setProgramme(programme);
    }

    /**
     * Gets the student's ID.
     *
     * @return The student ID
     */
    public String getId() {
        return id;
    }

    /**
     * Gets the student's first name.
     *
     * @return The first name
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the student's first name with validation.
     *
     * @param firstName The first name to set
     * @throws IllegalArgumentException if firstName is null or blank
     */
    public void setFirstName(String firstName) {
        if (firstName == null || firstName.isBlank()) {
            throw new IllegalArgumentException("First name cannot be empty");
        }
        this.firstName = firstName;
    }

    /**
     * Gets the student's surname.
     *
     * @return The surname
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Sets the student's surname with validation.
     *
     * @param surname The surname to set
     * @throws IllegalArgumentException if surname is null or blank
     */
    public void setSurname(String surname) {
        if (surname == null || surname.isBlank()) {
            throw new IllegalArgumentException("Surname cannot be empty");
        }
        this.surname = surname;
    }

    /**
     * Gets the student's full name (first name + surname).
     *
     * @return The full name
     */
    public String getFullName() {
        return firstName + " " + surname;
    }

    /**
     * Gets the student's email address.
     *
     * @return The email address
     */
    public String getEmail() {
        return email;
    }

    /**
     * Sets the student's email address with validation.
     *
     * @param email The email address to set
     * @throws IllegalArgumentException if email is invalid
     */
    public void setEmail(String email) {
        if (email == null || !email.contains("@")) {
            throw new IllegalArgumentException("Invalid email address");
        }
        this.email = email;
    }

    /**
     * Gets the student's date of birth.
     *
     * @return The date of birth
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Sets the student's date of birth with validation.
     *
     * @param dateOfBirth The date of birth to set
     * @throws IllegalArgumentException if dateOfBirth is null or blank
     */
    public void setDateOfBirth(String dateOfBirth) {
        if (dateOfBirth == null || dateOfBirth.isBlank()) {
            throw new IllegalArgumentException("Date of birth cannot be empty");
        }
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Gets the student's academic programme.
     *
     * @return The programme name (e.g., "Computer Science")
     */
    public String getProgramme() {
        return programme;
    }

    /**
     * Sets the student's academic programme with validation.
     *
     * @param programme The programme name to set
     * @throws IllegalArgumentException if programme is null or blank
     */
    public void setProgramme(String programme) {
        // Validate that programme is not null or empty
        if (programme == null || programme.isBlank()) {
            throw new IllegalArgumentException("Programme cannot be empty");
        }
        this.programme = programme;
    }

    /**
     * Returns a string representation of the Student object.
     * Includes all student details.
     *
     * @return Formatted string with student details
     */
    @Override
    public String toString() {
        return "Student: " + id + " | " + getFullName() + " | " + email + " | DOB: " + dateOfBirth + " | Programme: " + programme;
    }
}
