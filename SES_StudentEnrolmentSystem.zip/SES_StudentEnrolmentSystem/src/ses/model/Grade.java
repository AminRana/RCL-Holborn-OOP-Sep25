package ses.model;

/**
 * Grade class represents a student's grade/score for a course.
 * Stores a numerical score (0-100) and determines pass/fail status.
 * This is an immutable class - once created, the score cannot be changed.
 */
public class Grade {

    // The numerical score (0-100 scale)
    // Made final to ensure immutability - score cannot change after creation
    private final double score;

    /**
     * Constructor to create a new Grade object.
     * Validates that the score is within the valid range (0-100).
     *
     * @param score The numerical grade score (must be between 0 and 100 inclusive)
     * @throws IllegalArgumentException if score is less than 0 or greater than 100
     */
    public Grade(double score) {
        // Validate score is within acceptable range
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100");
        }
        this.score = score;
    }

    /**
     * Gets the numerical score.
     *
     * @return The score value (0-100)
     */
    public double getScore() {
        return score;
    }

    /**
     * Determines if this grade is a passing grade.
     * Pass mark is set to 40.0 - you can change this if your institution uses a different threshold.
     *
     * @return true if score >= 40.0 (passing), false otherwise (failing)
     */
    public boolean isPass() {
        // Pass threshold is 40% - adjust this constant if needed
        return score >= 40.0;
    }

    /**
     * Returns a string representation of the grade.
     * Format: "score (PASS)" or "score (FAIL)"
     *
     * @return Formatted string showing score and pass/fail status
     */
    @Override
    public String toString() {
        return score + " (" + (isPass() ? "PASS" : "FAIL") + ")";
    }
}