package ses.model;

/**
 * Course class represents an academic course in the enrollment system.
 * Stores course code, title, and credit value.
 * This is an immutable class - once created, course details cannot be changed.
 */
public class Course {

    // The unique course code (e.g., "CS101", "MATH201")
    private final String code;

    // The full title/name of the course
    private final String title;

    // The number of credits this course is worth
    private final int credits;

    /**
     * Constructor to create a new Course object.
     * Validates all parameters before creating the course.
     *
     * @param code The course code (e.g., "CS101") - must not be empty
     * @param title The course title (e.g., "Programming Fundamentals") - must not be empty
     * @param credits The number of credits (must be positive)
     * @throws IllegalArgumentException if any parameter is invalid
     */
    public Course(String code, String title, int credits) {
        // Validate course code is not null or empty
        if (code == null || code.isBlank()) {
            throw new IllegalArgumentException("Course code cannot be empty");
        }
        // Validate course title is not null or empty
        if (title == null || title.isBlank()) {
            throw new IllegalArgumentException("Course title cannot be empty");
        }
        // Validate credits is a positive number
        if (credits <= 0) {
            throw new IllegalArgumentException("Credits must be positive");
        }

        // Set the immutable fields
        this.code = code;
        this.title = title;
        this.credits = credits;
    }

    /**
     * Gets the course code.
     *
     * @return The course code (e.g., "CS101")
     */
    public String getCode() {
        return code;
    }

    /**
     * Gets the course title.
     *
     * @return The course title (e.g., "Programming Fundamentals")
     */
    public String getTitle() {
        return title;
    }

    /**
     * Gets the number of credits for this course.
     *
     * @return The credit value
     */
    public int getCredits() {
        return credits;
    }

    /**
     * Returns a string representation of the course.
     * Format: "CODE - Title (X credits)"
     *
     * @return Formatted string with course details
     */
    @Override
    public String toString() {
        return code + " - " + title + " (" + credits + " credits)";
    }

    /**
     * Checks if two courses are equal.
     * Courses are considered equal if they have the same course code.
     * Title and credits are not considered in equality check.
     *
     * @param obj The object to compare with
     * @return true if courses have the same code, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;  // Same object reference
        if (obj == null || getClass() != obj.getClass()) return false;  // Null or different class
        Course course = (Course) obj;
        return code.equals(course.code);  // Compare by course code only
    }

    /**
     * Returns hash code based on course code.
     * Ensures that equal courses (same code) have the same hash code.
     *
     * @return Hash code value
     */
    @Override
    public int hashCode() {
        return code.hashCode();
    }

    public static void main(String[] args) {
        System.out.println("=== Testing Course Class ===\n");

        // Test 1: Create a valid course
        try {
            Course course1 = new Course("CS101", "Programming Fundamentals", 15);
            System.out.println("✓ Course created successfully:");
            System.out.println("  " + course1);
        } catch (Exception e) {
            System.out.println("✗ Failed to create course: " + e.getMessage());
        }

        // Test 2: Test getters
        try {
            Course course2 = new Course("MATH101", "Calculus I", 15);
            System.out.println("\n✓ Testing getters:");
            System.out.println("  Code: " + course2.getCode());
            System.out.println("  Title: " + course2.getTitle());
            System.out.println("  Credits: " + course2.getCredits());
        } catch (Exception e) {
            System.out.println("✗ Failed: " + e.getMessage());
        }

        // Test 3: Test validation - empty code
        try {
            Course invalidCourse = new Course("", "Some Title", 15);
            System.out.println("\n✗ Should have thrown exception for empty code");
        } catch (IllegalArgumentException e) {
            System.out.println("\n✓ Correctly rejected empty code: " + e.getMessage());
        }

        // Test 4: Test validation - empty title
        try {
            Course invalidCourse = new Course("CS101", "", 15);
            System.out.println("✗ Should have thrown exception for empty title");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Correctly rejected empty title: " + e.getMessage());
        }

        // Test 5: Test validation - invalid credits
        try {
            Course invalidCourse = new Course("CS101", "Programming", 0);
            System.out.println("✗ Should have thrown exception for zero credits");
        } catch (IllegalArgumentException e) {
            System.out.println("✓ Correctly rejected zero credits: " + e.getMessage());
        }

        // Test 6: Test equals
        try {
            Course course3 = new Course("CS101", "Programming Fundamentals", 15);
            Course course4 = new Course("CS101", "Different Title", 20);
            Course course5 = new Course("CS102", "Data Structures", 15);

            System.out.println("\n✓ Testing equals:");
            System.out.println("  Same code (CS101 vs CS101): " + course3.equals(course4));
            System.out.println("  Different code (CS101 vs CS102): " + course3.equals(course5));
        } catch (Exception e) {
            System.out.println("✗ Failed: " + e.getMessage());
        }

        System.out.println("\n=== All Course Tests Complete ===");
    }
}
