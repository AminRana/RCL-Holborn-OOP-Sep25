package ses.dao;

import ses.database.DatabaseConnection;
import ses.model.Course;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * CourseDAO (Data Access Object) handles all database operations for Course entities.
 * This class provides CRUD (Create, Read, Update, Delete) operations for courses.
 * Uses JDBC to interact with the MySQL database.
 */
public class CourseDAO {

    /**
     * Adds a new course to the database.
     * Inserts course code, title, and credits into the courses table.
     *
     * @param course The Course object to add to the database
     * @throws SQLException if database operation fails (e.g., duplicate course code)
     */
    public void addCourse(Course course) throws SQLException {
        // SQL INSERT statement with placeholders for parameters
        String sql = "INSERT INTO courses (code, title, credits) VALUES (?, ?, ?)";

        // Try-with-resources ensures connection and statement are closed automatically
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set parameters for the prepared statement
            stmt.setString(1, course.getCode());    // Parameter 1: course code
            stmt.setString(2, course.getTitle());   // Parameter 2: course title
            stmt.setInt(3, course.getCredits());    // Parameter 3: credits

            // Execute the INSERT statement
            stmt.executeUpdate();
        }
    }

    /**
     * Retrieves a course from the database by its course code.
     *
     * @param code The course code to search for (e.g., "CS101")
     * @return Course object if found, null if not found
     * @throws SQLException if database operation fails
     */
    public Course getCourseByCode(String code) throws SQLException {
        // SQL SELECT statement to find course by code
        String sql = "SELECT * FROM courses WHERE code = ?";

        // Try-with-resources for automatic resource management
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the course code parameter in the WHERE clause
            stmt.setString(1, code);

            // Execute query and get results
            try (ResultSet rs = stmt.executeQuery()) {
                // Check if a course was found
                if (rs.next()) {
                    // Create and return Course object from database row
                    return new Course(
                        rs.getString("code"),      // Get code column
                        rs.getString("title"),     // Get title column
                        rs.getInt("credits")       // Get credits column
                    );
                }
            }
        }
        // Return null if no course found with this code
        return null;
    }

    /**
     * Retrieves all courses from the database.
     * Courses are ordered by course code for consistent display.
     *
     * @return List of all Course objects (empty list if no courses exist)
     * @throws SQLException if database operation fails
     */
    public List<Course> getAllCourses() throws SQLException {
        // Create empty list to store courses
        List<Course> courses = new ArrayList<>();

        // SQL SELECT statement to get all courses, ordered by code
        String sql = "SELECT * FROM courses ORDER BY code";

        // Try-with-resources for connection, statement, and result set
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            // Loop through all rows in the result set
            while (rs.next()) {
                // Create Course object from current row
                Course course = new Course(
                    rs.getString("code"),
                    rs.getString("title"),
                    rs.getInt("credits")
                );
                // Add course to the list
                courses.add(course);
            }
        }
        // Return the list of courses (may be empty if no courses in database)
        return courses;
    }

    /**
     * Checks if a course with the given code exists in the database.
     * Useful for validation before adding or enrolling in courses.
     *
     * @param code The course code to check
     * @return true if course exists, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean courseExists(String code) throws SQLException {
        // SQL query to count courses with this code (should be 0 or 1)
        String sql = "SELECT COUNT(*) FROM courses WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the course code parameter
            stmt.setString(1, code);

            // Execute query
            try (ResultSet rs = stmt.executeQuery()) {
                // Check the count result
                if (rs.next()) {
                    // Return true if count > 0 (course exists)
                    return rs.getInt(1) > 0;
                }
            }
        }
        // Return false if query failed or no result
        return false;
    }

    /**
     * Deletes a course from the database.
     * WARNING: This will also delete all related enrollments and grades due to foreign key constraints.
     *
     * @param code The course code to delete
     * @throws SQLException if database operation fails
     */
    public void deleteCourse(String code) throws SQLException {
        // SQL DELETE statement
        String sql = "DELETE FROM courses WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the course code to delete
            stmt.setString(1, code);

            // Execute the DELETE statement
            stmt.executeUpdate();
        }
    }

    /**
     * Updates an existing course's information in the database.
     * The course code cannot be changed (used in WHERE clause).
     * Only title and credits can be updated.
     *
     * @param course The Course object with updated information
     * @throws SQLException if database operation fails or course doesn't exist
     */
    public void updateCourse(Course course) throws SQLException {
        // SQL UPDATE statement - updates title and credits, not code
        String sql = "UPDATE courses SET title = ?, credits = ? WHERE code = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set new values for updatable fields
            stmt.setString(1, course.getTitle());   // Update title
            stmt.setInt(2, course.getCredits());    // Update credits
            stmt.setString(3, course.getCode());    // WHERE clause - which course to update

            // Execute the UPDATE statement
            stmt.executeUpdate();
        }
    }
}
