package ses.dao;

import ses.database.DatabaseConnection;
import ses.model.Course;
import ses.model.Enrollment;
import ses.model.Grade;
import ses.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * EnrollmentDAO (Data Access Object) handles all database operations for Enrollment entities.
 * Manages the relationship between students, courses, and grades.
 * IMPORTANT: Grades are stored in a SEPARATE table (grades), not in the enrollments table.
 */
public class EnrollmentDAO {

    // DAO instances for fetching related Student and Course objects
    private final StudentDAO studentDAO = new StudentDAO();
    private final CourseDAO courseDAO = new CourseDAO();

    /**
     * Adds a new enrollment to the database.
     * NOTE: This only inserts into the enrollments table (student_id, course_code, semester).
     * Grades are NOT stored here - they go in the separate grades table via updateGrade().
     *
     * @param enrollment The Enrollment object to add
     * @throws SQLException if database operation fails (e.g., duplicate enrollment)
     */
    public void addEnrollment(Enrollment enrollment) throws SQLException {
        // SQL INSERT - only stores enrollment info, NOT grade
        String sql = "INSERT INTO enrollments (student_id, course_code, semester) VALUES (?, ?, ?)";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the three enrollment parameters
            stmt.setString(1, enrollment.getStudent().getId());    // Which student
            stmt.setString(2, enrollment.getCourse().getCode());   // Which course
            stmt.setString(3, enrollment.getSemester());           // Which semester

            // Execute the INSERT statement
            stmt.executeUpdate();
        }
    }

    /**
     * Retrieves all enrollments for a specific student.
     * Uses LEFT JOIN to fetch grades from the separate grades table.
     * Returns enrollments ordered by semester (most recent first).
     *
     * @param studentId The student ID to get enrollments for
     * @return List of Enrollment objects (with grades if available)
     * @throws SQLException if database operation fails
     */
    public List<Enrollment> getEnrollmentsByStudent(String studentId) throws SQLException {
        List<Enrollment> enrollments = new ArrayList<>();

        // SQL query with LEFT JOIN to grades table
        // LEFT JOIN ensures we get enrollments even if no grade exists yet
        String sql = "SELECT e.*, g.grade_score " +
                     "FROM enrollments e " +
                     "LEFT JOIN grades g ON e.student_id = g.student_id " +
                     "AND e.course_code = g.course_code " +
                     "AND e.semester = g.semester " +
                     "WHERE e.student_id = ? ORDER BY e.semester DESC";

        // Step 1: Collect all enrollment data from ResultSet
        // We do this first to avoid "ResultSet closed" errors
        List<EnrollmentData> enrollmentDataList = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the student ID parameter
            stmt.setString(1, studentId);

            // Execute query and extract data
            ResultSet rs = stmt.executeQuery();

            // Loop through all enrollment rows
            while (rs.next()) {
                // Store data in temporary object
                EnrollmentData data = new EnrollmentData();
                data.courseCode = rs.getString("course_code");
                data.semester = rs.getString("semester");
                data.gradeScore = rs.getDouble("grade_score");
                data.wasNull = rs.wasNull();  // Check if grade_score was NULL
                enrollmentDataList.add(data);
            }
        }

        // Step 2: Fetch student object once (same for all enrollments)
        Student student = studentDAO.getStudentById(studentId);

        // Step 3: Build Enrollment objects from collected data
        for (EnrollmentData data : enrollmentDataList) {
            // Fetch course object for this enrollment
            Course course = courseDAO.getCourseByCode(data.courseCode);

            // Only create enrollment if both student and course exist
            if (student != null && course != null) {
                // Create enrollment object
                Enrollment enrollment = new Enrollment(student, course, data.semester);

                // Add grade if it exists (wasNull = false means grade exists)
                if (!data.wasNull) {
                    enrollment.setGrade(new Grade(data.gradeScore));
                }

                enrollments.add(enrollment);
            }
        }
        return enrollments;
    }

    /**
     * Helper class to temporarily store enrollment data from ResultSet.
     * Used to avoid "ResultSet closed" errors when making additional database calls.
     */
    private static class EnrollmentData {
        String courseCode;   // The course code for this enrollment
        String semester;     // The semester identifier
        double gradeScore;   // The grade score (if exists)
        boolean wasNull;     // True if grade_score was NULL in database
    }

    /**
     * Retrieves ALL enrollments from the database (for all students).
     * Uses LEFT JOIN to fetch grades from the separate grades table.
     * Returns enrollments ordered by semester (most recent first), then by student ID.
     *
     * @return List of all Enrollment objects (with grades if available)
     * @throws SQLException if database operation fails
     */
    public List<Enrollment> getAllEnrollments() throws SQLException {
        List<Enrollment> enrollments = new ArrayList<>();

        // SQL query with LEFT JOIN to grades table
        String sql = "SELECT e.*, g.grade_score " +
                     "FROM enrollments e " +
                     "LEFT JOIN grades g ON e.student_id = g.student_id " +
                     "AND e.course_code = g.course_code " +
                     "AND e.semester = g.semester " +
                     "ORDER BY e.semester DESC, e.student_id";

        // Step 1: Collect all enrollment data from ResultSet
        List<AllEnrollmentData> enrollmentDataList = new ArrayList<>();

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            // Loop through all enrollment rows
            while (rs.next()) {
                // Store data in temporary object
                AllEnrollmentData data = new AllEnrollmentData();
                data.studentId = rs.getString("student_id");
                data.courseCode = rs.getString("course_code");
                data.semester = rs.getString("semester");
                data.gradeScore = rs.getDouble("grade_score");
                data.wasNull = rs.wasNull();  // Check if grade_score was NULL
                enrollmentDataList.add(data);
            }
        }

        // Step 2: Build Enrollment objects from collected data
        for (AllEnrollmentData data : enrollmentDataList) {
            // Fetch student and course objects for this enrollment
            Student student = studentDAO.getStudentById(data.studentId);
            Course course = courseDAO.getCourseByCode(data.courseCode);

            // Only create enrollment if both student and course exist
            if (student != null && course != null) {
                // Create enrollment object
                Enrollment enrollment = new Enrollment(student, course, data.semester);

                // Add grade if it exists
                if (!data.wasNull) {
                    enrollment.setGrade(new Grade(data.gradeScore));
                }

                enrollments.add(enrollment);
            }
        }
        return enrollments;
    }

    /**
     * Helper class to temporarily store enrollment data from ResultSet.
     * Similar to EnrollmentData but includes studentId (for getAllEnrollments).
     */
    private static class AllEnrollmentData {
        String studentId;    // The student ID for this enrollment
        String courseCode;   // The course code for this enrollment
        String semester;     // The semester identifier
        double gradeScore;   // The grade score (if exists)
        boolean wasNull;     // True if grade_score was NULL in database
    }

    /**
     * Updates or inserts a grade in the GRADES table (not enrollments table).
     * First checks if a grade already exists for this enrollment.
     * If exists: UPDATE the grade_score
     * If not exists: INSERT a new grade record
     *
     * @param studentId The student ID
     * @param courseCode The course code
     * @param semester The semester identifier
     * @param score The grade score to set (0-100)
     * @throws SQLException if database operation fails
     */
    public void updateGrade(String studentId, String courseCode, String semester, double score) throws SQLException {
        // SQL statements for checking, inserting, and updating grades
        String checkSql = "SELECT COUNT(*) FROM grades WHERE student_id = ? AND course_code = ? AND semester = ?";
        String insertSql = "INSERT INTO grades (student_id, course_code, semester, grade_score) VALUES (?, ?, ?, ?)";
        String updateSql = "UPDATE grades SET grade_score = ? WHERE student_id = ? AND course_code = ? AND semester = ?";

        try (Connection conn = DatabaseConnection.getConnection()) {
            // Step 1: Check if grade already exists for this enrollment
            boolean gradeExists = false;
            try (PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
                checkStmt.setString(1, studentId);
                checkStmt.setString(2, courseCode);
                checkStmt.setString(3, semester);
                ResultSet rs = checkStmt.executeQuery();
                if (rs.next()) {
                    gradeExists = rs.getInt(1) > 0;  // Count > 0 means grade exists
                }
            }

            // Step 2: Either UPDATE existing grade or INSERT new grade
            if (gradeExists) {
                // Grade exists - UPDATE it
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSql)) {
                    updateStmt.setDouble(1, score);        // New score value
                    updateStmt.setString(2, studentId);    // WHERE student_id
                    updateStmt.setString(3, courseCode);   // WHERE course_code
                    updateStmt.setString(4, semester);     // WHERE semester
                    updateStmt.executeUpdate();
                }
            } else {
                // Grade doesn't exist - INSERT new record
                try (PreparedStatement insertStmt = conn.prepareStatement(insertSql)) {
                    insertStmt.setString(1, studentId);    // student_id
                    insertStmt.setString(2, courseCode);   // course_code
                    insertStmt.setString(3, semester);     // semester
                    insertStmt.setDouble(4, score);        // grade_score
                    insertStmt.executeUpdate();
                }
            }
        }
    }

    /**
     * Checks if an enrollment exists for a specific student, course, and semester.
     * Useful for validation to prevent duplicate enrollments.
     *
     * @param studentId The student ID to check
     * @param courseCode The course code to check
     * @param semester The semester to check
     * @return true if enrollment exists, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean enrollmentExists(String studentId, String courseCode, String semester) throws SQLException {
        // SQL query to count matching enrollments (should be 0 or 1)
        String sql = "SELECT COUNT(*) FROM enrollments WHERE student_id = ? AND course_code = ? AND semester = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the three parameters to check
            stmt.setString(1, studentId);
            stmt.setString(2, courseCode);
            stmt.setString(3, semester);

            // Execute query
            ResultSet rs = stmt.executeQuery();

            // Check the count result
            if (rs.next()) {
                return rs.getInt(1) > 0;  // Return true if count > 0
            }
        }
        // Return false if query failed or no result
        return false;
    }
}
