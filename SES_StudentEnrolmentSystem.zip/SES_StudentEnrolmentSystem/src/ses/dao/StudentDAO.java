package ses.dao;

import ses.database.DatabaseConnection;
import ses.model.Student;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * StudentDAO (Data Access Object) handles all database operations for Student entities.
 * This class provides CRUD (Create, Read, Update, Delete) operations for students.
 * Uses JDBC to interact with the MySQL database.
 */
public class StudentDAO {

    /**
     * Adds a new student to the database.
     * Inserts all student information into the students table.
     *
     * @param student The Student object to add to the database
     * @throws SQLException if database operation fails (e.g., duplicate ID, connection error)
     */
    public void addStudent(Student student) throws SQLException {
        // SQL INSERT statement with placeholders (?) for parameters
        String sql = "INSERT INTO students (id, first_name, surname, email, date_of_birth, programme) VALUES (?, ?, ?, ?, ?, ?)";

        // Try-with-resources ensures connection and statement are closed automatically
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Debug output to track what's being inserted
            System.out.println("\n=== DEBUG: Adding Student to Database ===");
            System.out.println("  Student ID: " + student.getId());
            System.out.println("  Name: " + student.getFirstName() + " " + student.getSurname());
            System.out.println("  Email: " + student.getEmail());
            System.out.println("  DOB: " + student.getDateOfBirth());
            System.out.println("  Programme: " + student.getProgramme());

            // Set parameters for the prepared statement (prevents SQL injection)
            stmt.setString(1, student.getId());           // Parameter 1: student ID
            stmt.setString(2, student.getFirstName());    // Parameter 2: first name
            stmt.setString(3, student.getSurname());      // Parameter 3: surname
            stmt.setString(4, student.getEmail());        // Parameter 4: email
            stmt.setString(5, student.getDateOfBirth());  // Parameter 5: date of birth
            stmt.setString(6, student.getProgramme());    // Parameter 6: programme

            // Execute the INSERT statement and get number of rows affected
            int rowsAffected = stmt.executeUpdate();
            System.out.println("✓ Student inserted successfully!");
            System.out.println("  Rows affected: " + rowsAffected);
            System.out.println("==========================================\n");
        } catch (SQLException e) {
            // Log detailed error information for debugging
            System.err.println("\n✗ ERROR: Failed to insert student!");
            System.err.println("  SQL State: " + e.getSQLState());
            System.err.println("  Error Code: " + e.getErrorCode());
            System.err.println("  Message: " + e.getMessage());
            System.err.println("==========================================\n");
            throw e;  // Re-throw exception to caller
        }
    }

    /**
     * Retrieves a student from the database by their ID.
     *
     * @param id The student ID to search for (e.g., "SE001001")
     * @return Student object if found, null if not found
     * @throws SQLException if database operation fails
     */
    public Student getStudentById(String id) throws SQLException {
        // SQL SELECT statement to find student by ID
        String sql = "SELECT * FROM students WHERE id = ?";

        // Try-with-resources for automatic resource management
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the ID parameter in the WHERE clause
            stmt.setString(1, id);

            // Execute query and get results
            ResultSet rs = stmt.executeQuery();

            // Check if a student was found
            if (rs.next()) {
                // Create and return Student object from database row
                return new Student(
                    rs.getString("id"),              // Get id column
                    rs.getString("first_name"),      // Get first_name column
                    rs.getString("surname"),         // Get surname column
                    rs.getString("email"),           // Get email column
                    rs.getString("date_of_birth"),   // Get date_of_birth column
                    rs.getString("programme")        // Get programme column
                );
            }
        }
        // Return null if no student found with this ID
        return null;
    }

    /**
     * Retrieves all students from the database.
     * Students are ordered by ID for consistent display.
     *
     * @return List of all Student objects (empty list if no students exist)
     * @throws SQLException if database operation fails
     */
    public List<Student> getAllStudents() throws SQLException {
        // Create empty list to store students
        List<Student> students = new ArrayList<>();

        // SQL SELECT statement to get all students, ordered by ID
        String sql = "SELECT * FROM students ORDER BY id";

        // Try-with-resources for connection, statement, and result set
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            // Loop through all rows in the result set
            while (rs.next()) {
                // Create Student object from current row
                Student student = new Student(
                    rs.getString("id"),
                    rs.getString("first_name"),
                    rs.getString("surname"),
                    rs.getString("email"),
                    rs.getString("date_of_birth"),
                    rs.getString("programme")
                );
                // Add student to the list
                students.add(student);
            }
        }
        // Return the list of students (may be empty if no students in database)
        return students;
    }

    /**
     * Updates an existing student's information in the database.
     * The student ID cannot be changed (used in WHERE clause).
     *
     * @param student The Student object with updated information
     * @throws SQLException if database operation fails or student doesn't exist
     */
    public void updateStudent(Student student) throws SQLException {
        // SQL UPDATE statement - updates all fields except ID
        String sql = "UPDATE students SET first_name = ?, surname = ?, email = ?, date_of_birth = ?, programme = ? WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set new values for all updatable fields
            stmt.setString(1, student.getFirstName());    // Update first name
            stmt.setString(2, student.getSurname());      // Update surname
            stmt.setString(3, student.getEmail());        // Update email
            stmt.setString(4, student.getDateOfBirth());  // Update date of birth
            stmt.setString(5, student.getProgramme());    // Update programme
            stmt.setString(6, student.getId());           // WHERE clause - which student to update

            // Execute the UPDATE statement
            stmt.executeUpdate();
        }
    }

    /**
     * Deletes a student from the database.
     * WARNING: This will also delete all related enrollments and grades due to foreign key constraints.
     *
     * @param id The ID of the student to delete
     * @throws SQLException if database operation fails
     */
    public void deleteStudent(String id) throws SQLException {
        // SQL DELETE statement
        String sql = "DELETE FROM students WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the ID of the student to delete
            stmt.setString(1, id);

            // Execute the DELETE statement
            stmt.executeUpdate();
        }
    }

    /**
     * Checks if a student with the given ID exists in the database.
     * Useful for validation before adding or updating students.
     *
     * @param id The student ID to check
     * @return true if student exists, false otherwise
     * @throws SQLException if database operation fails
     */
    public boolean studentExists(String id) throws SQLException {
        // SQL query to count students with this ID (should be 0 or 1)
        String sql = "SELECT COUNT(*) FROM students WHERE id = ?";

        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            // Set the ID parameter
            stmt.setString(1, id);

            // Execute query
            ResultSet rs = stmt.executeQuery();

            // Check the count result
            if (rs.next()) {
                // Return true if count > 0 (student exists)
                return rs.getInt(1) > 0;
            }
        }
        // Return false if query failed or no result
        return false;
    }

    /**
     * Generates the next sequential student ID.
     * Format: SE001001, SE001002, SE001003, etc.
     * Queries the database for the last student ID and increments it.
     *
     * @return The next available student ID in format "SE######"
     * @throws SQLException if database operation fails
     */
    public String getNextStudentId() throws SQLException {
        // SQL query to get the last student ID (highest ID starting with 'SE')
        String sql = "SELECT id FROM students WHERE id LIKE 'SE%' ORDER BY id DESC LIMIT 1";

        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            // Check if any students exist
            if (rs.next()) {
                // Get the last student ID (e.g., "SE001010")
                String lastId = rs.getString("id");

                // Extract the numeric part by removing "SE" prefix
                // Example: "SE001010" -> "001010"
                String numericPart = lastId.substring(2);

                // Convert to integer and increment by 1
                int nextNumber = Integer.parseInt(numericPart) + 1;

                // Format with leading zeros (6 digits total)
                // Example: 1011 -> "SE001011"
                return String.format("SE%06d", nextNumber);
            } else {
                // No students exist yet, start with first ID
                return "SE001001";
            }
        }
    }
}
