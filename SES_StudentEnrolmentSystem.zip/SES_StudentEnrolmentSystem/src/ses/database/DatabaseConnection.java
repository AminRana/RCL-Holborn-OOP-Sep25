package ses.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * DatabaseConnection class handles all database connectivity for the Student Enrollment System.
 * This class uses a fresh connection pattern (not singleton) to avoid autocommit issues.
 * Each call to getConnection() creates a new database connection.
 */
public class DatabaseConnection {

    // Database configuration constants
    // JDBC URL format: jdbc:mysql://[host]:[port]/[database]?[parameters]
    private static final String URL = "jdbc:mysql://localhost:3306/student_enrollment_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USERNAME = "root";  // MySQL username - change if different
    private static final String PASSWORD = "root";  // MySQL password - UPDATE THIS to match your MySQL root password

    /**
     * Private constructor to prevent instantiation of this utility class.
     * This class only provides static methods for database operations.
     */
    private DatabaseConnection() {
    }

    /**
     * Creates and returns a new database connection.
     * IMPORTANT: This creates a FRESH connection each time to ensure proper autocommit behavior.
     * Each connection has autocommit enabled by default for immediate data persistence.
     *
     * @return A new Connection object connected to the student_enrollment_db database
     * @throws SQLException if connection fails or JDBC driver is not found
     */
    public static Connection getConnection() throws SQLException {
        try {
            // Step 1: Load the MySQL JDBC Driver into memory
            // This is required before establishing any database connection
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Step 2: Create a new connection to the database using DriverManager
            // This establishes a TCP connection to the MySQL server
            Connection conn = DriverManager.getConnection(URL, USERNAME, PASSWORD);

            // Step 3: Explicitly enable autocommit mode
            // AutoCommit = true means each SQL statement is committed immediately
            // This ensures data is saved to database right away without manual commit
            conn.setAutoCommit(true);

            // Debug output to confirm successful connection
            System.out.println("✓ Database connected successfully!");
            System.out.println("  Database: " + conn.getCatalog());
            System.out.println("  AutoCommit: " + conn.getAutoCommit());

            return conn;
        } catch (ClassNotFoundException e) {
            // This exception occurs if mysql-connector-java library is not in classpath
            throw new SQLException("MySQL JDBC Driver not found. Add mysql-connector-java to your project.", e);
        }
    }

    /**
     * Safely closes a database connection and releases resources.
     * Always call this method in a finally block or use try-with-resources.
     *
     * @param conn The Connection object to close (can be null)
     */
    public static void closeConnection(Connection conn) {
        // Check if connection is not null before attempting to close
        if (conn != null) {
            try {
                // Close the connection and release database resources
                conn.close();
                System.out.println("✓ Database connection closed.");
            } catch (SQLException e) {
                // Log error if closing fails, but don't throw exception
                System.err.println("Error closing database connection: " + e.getMessage());
            }
        }
    }

    /**
     * Main method to test database connection.
     * Run this to verify that your database is properly configured.
     * This will attempt to connect and then close the connection.
     *
     * @param args Command line arguments (not used)
     */
    public static void main(String[] args) {
        try {
            // Attempt to get a database connection
            Connection conn = DatabaseConnection.getConnection();

            // Verify the connection is valid and not closed
            if (conn != null && !conn.isClosed()) {
                System.out.println("✓ Database connection test successful!");
                System.out.println("  Database: " + conn.getCatalog());

                // Always close the connection when done
                closeConnection(conn);
            }
        } catch (SQLException e) {
            // Connection failed - print helpful error message
            System.err.println("✗ Database connection failed!");
            System.err.println("  Error: " + e.getMessage());
            System.err.println("\nMake sure:");
            System.err.println("  1. MySQL server is running");
            System.err.println("  2. Database 'student_enrollment_db' exists");
            System.err.println("  3. Username and password are correct");
            System.err.println("  4. MySQL Connector/J is added to your project");
        }
    }
}
