package ses.database;

import java.sql.Connection;
import java.sql.Statement;

public class DatabaseInitializer {

    public static void initializeTables() {
        try (Connection conn = DatabaseConnection.getConnection();
             Statement stmt = conn.createStatement()) {

            // Create students table
            String createStudentsTable = """
                CREATE TABLE IF NOT EXISTS students (
                    id VARCHAR(50) PRIMARY KEY,
                    first_name VARCHAR(100) NOT NULL,
                    surname VARCHAR(100) NOT NULL,
                    email VARCHAR(100) NOT NULL UNIQUE,
                    date_of_birth VARCHAR(20) NOT NULL,
                    programme VARCHAR(100) NOT NULL
                )
                """;
            stmt.execute(createStudentsTable);

            // Create courses table
            String createCoursesTable = """
                CREATE TABLE IF NOT EXISTS courses (
                    code VARCHAR(20) PRIMARY KEY,
                    title VARCHAR(200) NOT NULL,
                    credits INT NOT NULL
                )
                """;
            stmt.execute(createCoursesTable);

            // Create enrollments table
            String createEnrollmentsTable = """
                CREATE TABLE IF NOT EXISTS enrollments (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id VARCHAR(50) NOT NULL,
                    course_code VARCHAR(20) NOT NULL,
                    semester VARCHAR(20) NOT NULL,
                    grade_score DOUBLE DEFAULT NULL,
                    FOREIGN KEY (student_id) REFERENCES students(id),
                    FOREIGN KEY (course_code) REFERENCES courses(code),
                    UNIQUE KEY (student_id, course_code, semester)
                )
                """;
            stmt.execute(createEnrollmentsTable);

            System.out.println("✓ Database tables initialized successfully!");

        } catch (Exception e) {
            System.err.println("Error initializing database tables: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
