package ses;

import org.junit.jupiter.api.Test;
import ses.service.EnrollmentService;

import static org.junit.jupiter.api.Assertions.*;

public class EnrollmentServiceTest {

    @Test
    void registerStudent_shouldStoreStudent() {
        EnrollmentService service = new EnrollmentService();

        service.registerStudent("S001", "Ada", "Lovelace", "ada@uni.ac.uk", "1815-12-10", "Computer Science");

        // If no exception happens, registration worked.
        assertEquals(0, service.getStudentReport("S001").size());
    }

    @Test
    void registerStudent_duplicateId_shouldThrow() {
        EnrollmentService service = new EnrollmentService();

        service.registerStudent("S001", "Ada", "Lovelace", "ada@uni.ac.uk", "1815-12-10", "Computer Science");

        assertThrows(IllegalStateException.class, () ->
                service.registerStudent("S001", "Another", "Name", "another@uni.ac.uk", "2000-01-01", "IT")
        );
    }

    @Test
    void addCourse_duplicateCode_shouldThrow() {
        EnrollmentService service = new EnrollmentService();

        service.addCourse("SWE4305", "Object-Oriented Programming", 20);

        assertThrows(IllegalStateException.class, () ->
                service.addCourse("SWE4305", "Different Title", 20)
        );
    }

    @Test
    void enrolStudent_shouldCreateEnrollment() {
        EnrollmentService service = new EnrollmentService();

        service.registerStudent("S001", "Ada", "Lovelace", "ada@uni.ac.uk", "1815-12-10", "Computer Science");
        service.addCourse("SWE4305", "Object-Oriented Programming", 20);

        service.enrolStudent("S001", "SWE4305", "2025-S1");

        assertEquals(1, service.getStudentReport("S001").size());
    }

    @Test
    void enrolStudent_duplicateSameSemester_shouldThrow() {
        EnrollmentService service = new EnrollmentService();

        service.registerStudent("S001", "Ada", "Lovelace", "ada@uni.ac.uk", "1815-12-10", "Computer Science");
        service.addCourse("SWE4305", "Object-Oriented Programming", 20);

        service.enrolStudent("S001", "SWE4305", "2025-S1");

        assertThrows(IllegalStateException.class, () ->
                service.enrolStudent("S001", "SWE4305", "2025-S1")
        );
    }

    @Test
    void recordGrade_invalidScore_shouldThrow() {
        EnrollmentService service = new EnrollmentService();

        service.registerStudent("S001", "Ada", "Lovelace", "ada@uni.ac.uk", "1815-12-10", "Computer Science");
        service.addCourse("SWE4305", "Object-Oriented Programming", 20);
        service.enrolStudent("S001", "SWE4305", "2025-S1");

        assertThrows(IllegalArgumentException.class, () ->
                service.recordGrade("S001", "SWE4305", "2025-S1", -10)
        );
    }

    @Test
    void recordGrade_validScore_shouldWork() {
        EnrollmentService service = new EnrollmentService();

        service.registerStudent("S001", "Ada", "Lovelace", "ada@uni.ac.uk", "1815-12-10", "Computer Science");
        service.addCourse("SWE4305", "Object-Oriented Programming", 20);
        service.enrolStudent("S001", "SWE4305", "2025-S1");

        service.recordGrade("S001", "SWE4305", "2025-S1", 75);

        // report should still have 1 enrollment
        assertEquals(1, service.getStudentReport("S001").size());
    }
}