package ses;

import ses.database.DatabaseInitializer;
import ses.service.EnrollmentService;
import ses.ui.MainFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Initialize database tables
        DatabaseInitializer.initializeTables();

        // Set look and feel to system default
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Create and show GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            EnrollmentService service = new EnrollmentService();
            MainFrame frame = new MainFrame(service);
            frame.setVisible(true);
        });
    }
}