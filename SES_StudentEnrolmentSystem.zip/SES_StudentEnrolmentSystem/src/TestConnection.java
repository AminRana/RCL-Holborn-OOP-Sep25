import java.sql.Connection;
import java.sql.DriverManager;

public class TestConnection {
    public static void main(String[] args) {
        String[] passwords = {
            "",                    // Empty password
            "clickCLICK11",       // Without @
            "clickCLICK11@",      // With @
            "root",               // Common default
            "mysql",              // Common default
            "password"            // Common default
        };

        String url = "jdbc:mysql://localhost:3306/mysql?useSSL=false&allowPublicKeyRetrieval=true";
        String username = "root";

        System.out.println("Testing different passwords...\n");

        for (String password : passwords) {
            try {
                Connection conn = DriverManager.getConnection(url, username, password);
                System.out.println("✓ SUCCESS! Password is: \"" + password + "\"");
                conn.close();
                return;
            } catch (Exception e) {
                System.out.println("✗ Failed with password: \"" + password + "\"");
            }
        }

        System.out.println("\nNone of the common passwords worked.");
        System.out.println("Please check your MySQL Workbench connection settings for the exact password.");
    }
}
