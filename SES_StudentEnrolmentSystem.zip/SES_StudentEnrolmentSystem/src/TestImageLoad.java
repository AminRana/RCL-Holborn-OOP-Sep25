import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;

public class TestImageLoad {
    public static void main(String[] args) {
        System.out.println("=== Testing Image Loading ===\n");

        // Test 1: Load from classpath
        System.out.println("Test 1: Loading from classpath (/icons/bg.png)");
        try (InputStream is = TestImageLoad.class.getResourceAsStream("/icons/bg.png")) {
            if (is != null) {
                BufferedImage img = ImageIO.read(is);
                System.out.println("✓ SUCCESS: Loaded from classpath");
                System.out.println("  Dimensions: " + img.getWidth() + "x" + img.getHeight());
            } else {
                System.out.println("✗ FAILED: Resource not found in classpath");
            }
        } catch (Exception e) {
            System.out.println("✗ ERROR: " + e.getMessage());
        }

        // Test 2: Load from file system
        System.out.println("\nTest 2: Loading from file (resources/icons/bg.png)");
        try {
            File f = new File("resources/icons/bg.png");
            if (f.exists()) {
                BufferedImage img = ImageIO.read(f);
                System.out.println("✓ SUCCESS: Loaded from file");
                System.out.println("  Dimensions: " + img.getWidth() + "x" + img.getHeight());
                System.out.println("  File path: " + f.getAbsolutePath());
            } else {
                System.out.println("✗ FAILED: File not found");
                System.out.println("  Looking for: " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            System.out.println("✗ ERROR: " + e.getMessage());
        }

        // Test 3: Check all icons
        System.out.println("\nTest 3: Checking all icon files in classpath:");
        String[] icons = {
            "/icons/bg.png",
            "/icons/student_management_bg.png",
            "/icons/enrollment_management_bg.png",
            "/icons/grade_management_bg.png",
            "/icons/courses_completed_bg.png",
            "/icons/reports_bg.png"
        };

        for (String icon : icons) {
            try (InputStream is = TestImageLoad.class.getResourceAsStream(icon)) {
                if (is != null) {
                    BufferedImage img = ImageIO.read(is);
                    System.out.println("  ✓ " + icon + " (" + img.getWidth() + "x" + img.getHeight() + ")");
                } else {
                    System.out.println("  ✗ " + icon + " (NOT FOUND)");
                }
            } catch (Exception e) {
                System.out.println("  ✗ " + icon + " (ERROR: " + e.getMessage() + ")");
            }
        }
    }
}
